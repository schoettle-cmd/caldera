"use strict";
var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// (disabled):crypto
var require_crypto = __commonJS({
  "(disabled):crypto"() {
  }
});

// ../../node_modules/tweetnacl/nacl-fast.js
var require_nacl_fast = __commonJS({
  "../../node_modules/tweetnacl/nacl-fast.js"(exports, module2) {
    (function(nacl2) {
      "use strict";
      var gf = function(init) {
        var i, r = new Float64Array(16);
        if (init) for (i = 0; i < init.length; i++) r[i] = init[i];
        return r;
      };
      var randombytes = function() {
        throw new Error("no PRNG");
      };
      var _0 = new Uint8Array(16);
      var _9 = new Uint8Array(32);
      _9[0] = 9;
      var gf0 = gf(), gf1 = gf([1]), _121665 = gf([56129, 1]), D = gf([30883, 4953, 19914, 30187, 55467, 16705, 2637, 112, 59544, 30585, 16505, 36039, 65139, 11119, 27886, 20995]), D2 = gf([61785, 9906, 39828, 60374, 45398, 33411, 5274, 224, 53552, 61171, 33010, 6542, 64743, 22239, 55772, 9222]), X = gf([54554, 36645, 11616, 51542, 42930, 38181, 51040, 26924, 56412, 64982, 57905, 49316, 21502, 52590, 14035, 8553]), Y = gf([26200, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214, 26214]), I = gf([41136, 18958, 6951, 50414, 58488, 44335, 6150, 12099, 55207, 15867, 153, 11085, 57099, 20417, 9344, 11139]);
      function ts64(x, i, h, l) {
        x[i] = h >> 24 & 255;
        x[i + 1] = h >> 16 & 255;
        x[i + 2] = h >> 8 & 255;
        x[i + 3] = h & 255;
        x[i + 4] = l >> 24 & 255;
        x[i + 5] = l >> 16 & 255;
        x[i + 6] = l >> 8 & 255;
        x[i + 7] = l & 255;
      }
      function vn(x, xi, y, yi, n) {
        var i, d = 0;
        for (i = 0; i < n; i++) d |= x[xi + i] ^ y[yi + i];
        return (1 & d - 1 >>> 8) - 1;
      }
      function crypto_verify_16(x, xi, y, yi) {
        return vn(x, xi, y, yi, 16);
      }
      function crypto_verify_32(x, xi, y, yi) {
        return vn(x, xi, y, yi, 32);
      }
      function core_salsa20(o, p, k, c) {
        var j0 = c[0] & 255 | (c[1] & 255) << 8 | (c[2] & 255) << 16 | (c[3] & 255) << 24, j1 = k[0] & 255 | (k[1] & 255) << 8 | (k[2] & 255) << 16 | (k[3] & 255) << 24, j2 = k[4] & 255 | (k[5] & 255) << 8 | (k[6] & 255) << 16 | (k[7] & 255) << 24, j3 = k[8] & 255 | (k[9] & 255) << 8 | (k[10] & 255) << 16 | (k[11] & 255) << 24, j4 = k[12] & 255 | (k[13] & 255) << 8 | (k[14] & 255) << 16 | (k[15] & 255) << 24, j5 = c[4] & 255 | (c[5] & 255) << 8 | (c[6] & 255) << 16 | (c[7] & 255) << 24, j6 = p[0] & 255 | (p[1] & 255) << 8 | (p[2] & 255) << 16 | (p[3] & 255) << 24, j7 = p[4] & 255 | (p[5] & 255) << 8 | (p[6] & 255) << 16 | (p[7] & 255) << 24, j8 = p[8] & 255 | (p[9] & 255) << 8 | (p[10] & 255) << 16 | (p[11] & 255) << 24, j9 = p[12] & 255 | (p[13] & 255) << 8 | (p[14] & 255) << 16 | (p[15] & 255) << 24, j10 = c[8] & 255 | (c[9] & 255) << 8 | (c[10] & 255) << 16 | (c[11] & 255) << 24, j11 = k[16] & 255 | (k[17] & 255) << 8 | (k[18] & 255) << 16 | (k[19] & 255) << 24, j12 = k[20] & 255 | (k[21] & 255) << 8 | (k[22] & 255) << 16 | (k[23] & 255) << 24, j13 = k[24] & 255 | (k[25] & 255) << 8 | (k[26] & 255) << 16 | (k[27] & 255) << 24, j14 = k[28] & 255 | (k[29] & 255) << 8 | (k[30] & 255) << 16 | (k[31] & 255) << 24, j15 = c[12] & 255 | (c[13] & 255) << 8 | (c[14] & 255) << 16 | (c[15] & 255) << 24;
        var x0 = j0, x1 = j1, x2 = j2, x3 = j3, x4 = j4, x5 = j5, x6 = j6, x7 = j7, x8 = j8, x9 = j9, x10 = j10, x11 = j11, x12 = j12, x13 = j13, x14 = j14, x15 = j15, u;
        for (var i = 0; i < 20; i += 2) {
          u = x0 + x12 | 0;
          x4 ^= u << 7 | u >>> 32 - 7;
          u = x4 + x0 | 0;
          x8 ^= u << 9 | u >>> 32 - 9;
          u = x8 + x4 | 0;
          x12 ^= u << 13 | u >>> 32 - 13;
          u = x12 + x8 | 0;
          x0 ^= u << 18 | u >>> 32 - 18;
          u = x5 + x1 | 0;
          x9 ^= u << 7 | u >>> 32 - 7;
          u = x9 + x5 | 0;
          x13 ^= u << 9 | u >>> 32 - 9;
          u = x13 + x9 | 0;
          x1 ^= u << 13 | u >>> 32 - 13;
          u = x1 + x13 | 0;
          x5 ^= u << 18 | u >>> 32 - 18;
          u = x10 + x6 | 0;
          x14 ^= u << 7 | u >>> 32 - 7;
          u = x14 + x10 | 0;
          x2 ^= u << 9 | u >>> 32 - 9;
          u = x2 + x14 | 0;
          x6 ^= u << 13 | u >>> 32 - 13;
          u = x6 + x2 | 0;
          x10 ^= u << 18 | u >>> 32 - 18;
          u = x15 + x11 | 0;
          x3 ^= u << 7 | u >>> 32 - 7;
          u = x3 + x15 | 0;
          x7 ^= u << 9 | u >>> 32 - 9;
          u = x7 + x3 | 0;
          x11 ^= u << 13 | u >>> 32 - 13;
          u = x11 + x7 | 0;
          x15 ^= u << 18 | u >>> 32 - 18;
          u = x0 + x3 | 0;
          x1 ^= u << 7 | u >>> 32 - 7;
          u = x1 + x0 | 0;
          x2 ^= u << 9 | u >>> 32 - 9;
          u = x2 + x1 | 0;
          x3 ^= u << 13 | u >>> 32 - 13;
          u = x3 + x2 | 0;
          x0 ^= u << 18 | u >>> 32 - 18;
          u = x5 + x4 | 0;
          x6 ^= u << 7 | u >>> 32 - 7;
          u = x6 + x5 | 0;
          x7 ^= u << 9 | u >>> 32 - 9;
          u = x7 + x6 | 0;
          x4 ^= u << 13 | u >>> 32 - 13;
          u = x4 + x7 | 0;
          x5 ^= u << 18 | u >>> 32 - 18;
          u = x10 + x9 | 0;
          x11 ^= u << 7 | u >>> 32 - 7;
          u = x11 + x10 | 0;
          x8 ^= u << 9 | u >>> 32 - 9;
          u = x8 + x11 | 0;
          x9 ^= u << 13 | u >>> 32 - 13;
          u = x9 + x8 | 0;
          x10 ^= u << 18 | u >>> 32 - 18;
          u = x15 + x14 | 0;
          x12 ^= u << 7 | u >>> 32 - 7;
          u = x12 + x15 | 0;
          x13 ^= u << 9 | u >>> 32 - 9;
          u = x13 + x12 | 0;
          x14 ^= u << 13 | u >>> 32 - 13;
          u = x14 + x13 | 0;
          x15 ^= u << 18 | u >>> 32 - 18;
        }
        x0 = x0 + j0 | 0;
        x1 = x1 + j1 | 0;
        x2 = x2 + j2 | 0;
        x3 = x3 + j3 | 0;
        x4 = x4 + j4 | 0;
        x5 = x5 + j5 | 0;
        x6 = x6 + j6 | 0;
        x7 = x7 + j7 | 0;
        x8 = x8 + j8 | 0;
        x9 = x9 + j9 | 0;
        x10 = x10 + j10 | 0;
        x11 = x11 + j11 | 0;
        x12 = x12 + j12 | 0;
        x13 = x13 + j13 | 0;
        x14 = x14 + j14 | 0;
        x15 = x15 + j15 | 0;
        o[0] = x0 >>> 0 & 255;
        o[1] = x0 >>> 8 & 255;
        o[2] = x0 >>> 16 & 255;
        o[3] = x0 >>> 24 & 255;
        o[4] = x1 >>> 0 & 255;
        o[5] = x1 >>> 8 & 255;
        o[6] = x1 >>> 16 & 255;
        o[7] = x1 >>> 24 & 255;
        o[8] = x2 >>> 0 & 255;
        o[9] = x2 >>> 8 & 255;
        o[10] = x2 >>> 16 & 255;
        o[11] = x2 >>> 24 & 255;
        o[12] = x3 >>> 0 & 255;
        o[13] = x3 >>> 8 & 255;
        o[14] = x3 >>> 16 & 255;
        o[15] = x3 >>> 24 & 255;
        o[16] = x4 >>> 0 & 255;
        o[17] = x4 >>> 8 & 255;
        o[18] = x4 >>> 16 & 255;
        o[19] = x4 >>> 24 & 255;
        o[20] = x5 >>> 0 & 255;
        o[21] = x5 >>> 8 & 255;
        o[22] = x5 >>> 16 & 255;
        o[23] = x5 >>> 24 & 255;
        o[24] = x6 >>> 0 & 255;
        o[25] = x6 >>> 8 & 255;
        o[26] = x6 >>> 16 & 255;
        o[27] = x6 >>> 24 & 255;
        o[28] = x7 >>> 0 & 255;
        o[29] = x7 >>> 8 & 255;
        o[30] = x7 >>> 16 & 255;
        o[31] = x7 >>> 24 & 255;
        o[32] = x8 >>> 0 & 255;
        o[33] = x8 >>> 8 & 255;
        o[34] = x8 >>> 16 & 255;
        o[35] = x8 >>> 24 & 255;
        o[36] = x9 >>> 0 & 255;
        o[37] = x9 >>> 8 & 255;
        o[38] = x9 >>> 16 & 255;
        o[39] = x9 >>> 24 & 255;
        o[40] = x10 >>> 0 & 255;
        o[41] = x10 >>> 8 & 255;
        o[42] = x10 >>> 16 & 255;
        o[43] = x10 >>> 24 & 255;
        o[44] = x11 >>> 0 & 255;
        o[45] = x11 >>> 8 & 255;
        o[46] = x11 >>> 16 & 255;
        o[47] = x11 >>> 24 & 255;
        o[48] = x12 >>> 0 & 255;
        o[49] = x12 >>> 8 & 255;
        o[50] = x12 >>> 16 & 255;
        o[51] = x12 >>> 24 & 255;
        o[52] = x13 >>> 0 & 255;
        o[53] = x13 >>> 8 & 255;
        o[54] = x13 >>> 16 & 255;
        o[55] = x13 >>> 24 & 255;
        o[56] = x14 >>> 0 & 255;
        o[57] = x14 >>> 8 & 255;
        o[58] = x14 >>> 16 & 255;
        o[59] = x14 >>> 24 & 255;
        o[60] = x15 >>> 0 & 255;
        o[61] = x15 >>> 8 & 255;
        o[62] = x15 >>> 16 & 255;
        o[63] = x15 >>> 24 & 255;
      }
      function core_hsalsa20(o, p, k, c) {
        var j0 = c[0] & 255 | (c[1] & 255) << 8 | (c[2] & 255) << 16 | (c[3] & 255) << 24, j1 = k[0] & 255 | (k[1] & 255) << 8 | (k[2] & 255) << 16 | (k[3] & 255) << 24, j2 = k[4] & 255 | (k[5] & 255) << 8 | (k[6] & 255) << 16 | (k[7] & 255) << 24, j3 = k[8] & 255 | (k[9] & 255) << 8 | (k[10] & 255) << 16 | (k[11] & 255) << 24, j4 = k[12] & 255 | (k[13] & 255) << 8 | (k[14] & 255) << 16 | (k[15] & 255) << 24, j5 = c[4] & 255 | (c[5] & 255) << 8 | (c[6] & 255) << 16 | (c[7] & 255) << 24, j6 = p[0] & 255 | (p[1] & 255) << 8 | (p[2] & 255) << 16 | (p[3] & 255) << 24, j7 = p[4] & 255 | (p[5] & 255) << 8 | (p[6] & 255) << 16 | (p[7] & 255) << 24, j8 = p[8] & 255 | (p[9] & 255) << 8 | (p[10] & 255) << 16 | (p[11] & 255) << 24, j9 = p[12] & 255 | (p[13] & 255) << 8 | (p[14] & 255) << 16 | (p[15] & 255) << 24, j10 = c[8] & 255 | (c[9] & 255) << 8 | (c[10] & 255) << 16 | (c[11] & 255) << 24, j11 = k[16] & 255 | (k[17] & 255) << 8 | (k[18] & 255) << 16 | (k[19] & 255) << 24, j12 = k[20] & 255 | (k[21] & 255) << 8 | (k[22] & 255) << 16 | (k[23] & 255) << 24, j13 = k[24] & 255 | (k[25] & 255) << 8 | (k[26] & 255) << 16 | (k[27] & 255) << 24, j14 = k[28] & 255 | (k[29] & 255) << 8 | (k[30] & 255) << 16 | (k[31] & 255) << 24, j15 = c[12] & 255 | (c[13] & 255) << 8 | (c[14] & 255) << 16 | (c[15] & 255) << 24;
        var x0 = j0, x1 = j1, x2 = j2, x3 = j3, x4 = j4, x5 = j5, x6 = j6, x7 = j7, x8 = j8, x9 = j9, x10 = j10, x11 = j11, x12 = j12, x13 = j13, x14 = j14, x15 = j15, u;
        for (var i = 0; i < 20; i += 2) {
          u = x0 + x12 | 0;
          x4 ^= u << 7 | u >>> 32 - 7;
          u = x4 + x0 | 0;
          x8 ^= u << 9 | u >>> 32 - 9;
          u = x8 + x4 | 0;
          x12 ^= u << 13 | u >>> 32 - 13;
          u = x12 + x8 | 0;
          x0 ^= u << 18 | u >>> 32 - 18;
          u = x5 + x1 | 0;
          x9 ^= u << 7 | u >>> 32 - 7;
          u = x9 + x5 | 0;
          x13 ^= u << 9 | u >>> 32 - 9;
          u = x13 + x9 | 0;
          x1 ^= u << 13 | u >>> 32 - 13;
          u = x1 + x13 | 0;
          x5 ^= u << 18 | u >>> 32 - 18;
          u = x10 + x6 | 0;
          x14 ^= u << 7 | u >>> 32 - 7;
          u = x14 + x10 | 0;
          x2 ^= u << 9 | u >>> 32 - 9;
          u = x2 + x14 | 0;
          x6 ^= u << 13 | u >>> 32 - 13;
          u = x6 + x2 | 0;
          x10 ^= u << 18 | u >>> 32 - 18;
          u = x15 + x11 | 0;
          x3 ^= u << 7 | u >>> 32 - 7;
          u = x3 + x15 | 0;
          x7 ^= u << 9 | u >>> 32 - 9;
          u = x7 + x3 | 0;
          x11 ^= u << 13 | u >>> 32 - 13;
          u = x11 + x7 | 0;
          x15 ^= u << 18 | u >>> 32 - 18;
          u = x0 + x3 | 0;
          x1 ^= u << 7 | u >>> 32 - 7;
          u = x1 + x0 | 0;
          x2 ^= u << 9 | u >>> 32 - 9;
          u = x2 + x1 | 0;
          x3 ^= u << 13 | u >>> 32 - 13;
          u = x3 + x2 | 0;
          x0 ^= u << 18 | u >>> 32 - 18;
          u = x5 + x4 | 0;
          x6 ^= u << 7 | u >>> 32 - 7;
          u = x6 + x5 | 0;
          x7 ^= u << 9 | u >>> 32 - 9;
          u = x7 + x6 | 0;
          x4 ^= u << 13 | u >>> 32 - 13;
          u = x4 + x7 | 0;
          x5 ^= u << 18 | u >>> 32 - 18;
          u = x10 + x9 | 0;
          x11 ^= u << 7 | u >>> 32 - 7;
          u = x11 + x10 | 0;
          x8 ^= u << 9 | u >>> 32 - 9;
          u = x8 + x11 | 0;
          x9 ^= u << 13 | u >>> 32 - 13;
          u = x9 + x8 | 0;
          x10 ^= u << 18 | u >>> 32 - 18;
          u = x15 + x14 | 0;
          x12 ^= u << 7 | u >>> 32 - 7;
          u = x12 + x15 | 0;
          x13 ^= u << 9 | u >>> 32 - 9;
          u = x13 + x12 | 0;
          x14 ^= u << 13 | u >>> 32 - 13;
          u = x14 + x13 | 0;
          x15 ^= u << 18 | u >>> 32 - 18;
        }
        o[0] = x0 >>> 0 & 255;
        o[1] = x0 >>> 8 & 255;
        o[2] = x0 >>> 16 & 255;
        o[3] = x0 >>> 24 & 255;
        o[4] = x5 >>> 0 & 255;
        o[5] = x5 >>> 8 & 255;
        o[6] = x5 >>> 16 & 255;
        o[7] = x5 >>> 24 & 255;
        o[8] = x10 >>> 0 & 255;
        o[9] = x10 >>> 8 & 255;
        o[10] = x10 >>> 16 & 255;
        o[11] = x10 >>> 24 & 255;
        o[12] = x15 >>> 0 & 255;
        o[13] = x15 >>> 8 & 255;
        o[14] = x15 >>> 16 & 255;
        o[15] = x15 >>> 24 & 255;
        o[16] = x6 >>> 0 & 255;
        o[17] = x6 >>> 8 & 255;
        o[18] = x6 >>> 16 & 255;
        o[19] = x6 >>> 24 & 255;
        o[20] = x7 >>> 0 & 255;
        o[21] = x7 >>> 8 & 255;
        o[22] = x7 >>> 16 & 255;
        o[23] = x7 >>> 24 & 255;
        o[24] = x8 >>> 0 & 255;
        o[25] = x8 >>> 8 & 255;
        o[26] = x8 >>> 16 & 255;
        o[27] = x8 >>> 24 & 255;
        o[28] = x9 >>> 0 & 255;
        o[29] = x9 >>> 8 & 255;
        o[30] = x9 >>> 16 & 255;
        o[31] = x9 >>> 24 & 255;
      }
      function crypto_core_salsa20(out, inp, k, c) {
        core_salsa20(out, inp, k, c);
      }
      function crypto_core_hsalsa20(out, inp, k, c) {
        core_hsalsa20(out, inp, k, c);
      }
      var sigma = new Uint8Array([101, 120, 112, 97, 110, 100, 32, 51, 50, 45, 98, 121, 116, 101, 32, 107]);
      function crypto_stream_salsa20_xor(c, cpos, m, mpos, b, n, k) {
        var z = new Uint8Array(16), x = new Uint8Array(64);
        var u, i;
        for (i = 0; i < 16; i++) z[i] = 0;
        for (i = 0; i < 8; i++) z[i] = n[i];
        while (b >= 64) {
          crypto_core_salsa20(x, z, k, sigma);
          for (i = 0; i < 64; i++) c[cpos + i] = m[mpos + i] ^ x[i];
          u = 1;
          for (i = 8; i < 16; i++) {
            u = u + (z[i] & 255) | 0;
            z[i] = u & 255;
            u >>>= 8;
          }
          b -= 64;
          cpos += 64;
          mpos += 64;
        }
        if (b > 0) {
          crypto_core_salsa20(x, z, k, sigma);
          for (i = 0; i < b; i++) c[cpos + i] = m[mpos + i] ^ x[i];
        }
        return 0;
      }
      function crypto_stream_salsa20(c, cpos, b, n, k) {
        var z = new Uint8Array(16), x = new Uint8Array(64);
        var u, i;
        for (i = 0; i < 16; i++) z[i] = 0;
        for (i = 0; i < 8; i++) z[i] = n[i];
        while (b >= 64) {
          crypto_core_salsa20(x, z, k, sigma);
          for (i = 0; i < 64; i++) c[cpos + i] = x[i];
          u = 1;
          for (i = 8; i < 16; i++) {
            u = u + (z[i] & 255) | 0;
            z[i] = u & 255;
            u >>>= 8;
          }
          b -= 64;
          cpos += 64;
        }
        if (b > 0) {
          crypto_core_salsa20(x, z, k, sigma);
          for (i = 0; i < b; i++) c[cpos + i] = x[i];
        }
        return 0;
      }
      function crypto_stream(c, cpos, d, n, k) {
        var s = new Uint8Array(32);
        crypto_core_hsalsa20(s, n, k, sigma);
        var sn = new Uint8Array(8);
        for (var i = 0; i < 8; i++) sn[i] = n[i + 16];
        return crypto_stream_salsa20(c, cpos, d, sn, s);
      }
      function crypto_stream_xor(c, cpos, m, mpos, d, n, k) {
        var s = new Uint8Array(32);
        crypto_core_hsalsa20(s, n, k, sigma);
        var sn = new Uint8Array(8);
        for (var i = 0; i < 8; i++) sn[i] = n[i + 16];
        return crypto_stream_salsa20_xor(c, cpos, m, mpos, d, sn, s);
      }
      var poly1305 = function(key) {
        this.buffer = new Uint8Array(16);
        this.r = new Uint16Array(10);
        this.h = new Uint16Array(10);
        this.pad = new Uint16Array(8);
        this.leftover = 0;
        this.fin = 0;
        var t0, t1, t2, t3, t4, t5, t6, t7;
        t0 = key[0] & 255 | (key[1] & 255) << 8;
        this.r[0] = t0 & 8191;
        t1 = key[2] & 255 | (key[3] & 255) << 8;
        this.r[1] = (t0 >>> 13 | t1 << 3) & 8191;
        t2 = key[4] & 255 | (key[5] & 255) << 8;
        this.r[2] = (t1 >>> 10 | t2 << 6) & 7939;
        t3 = key[6] & 255 | (key[7] & 255) << 8;
        this.r[3] = (t2 >>> 7 | t3 << 9) & 8191;
        t4 = key[8] & 255 | (key[9] & 255) << 8;
        this.r[4] = (t3 >>> 4 | t4 << 12) & 255;
        this.r[5] = t4 >>> 1 & 8190;
        t5 = key[10] & 255 | (key[11] & 255) << 8;
        this.r[6] = (t4 >>> 14 | t5 << 2) & 8191;
        t6 = key[12] & 255 | (key[13] & 255) << 8;
        this.r[7] = (t5 >>> 11 | t6 << 5) & 8065;
        t7 = key[14] & 255 | (key[15] & 255) << 8;
        this.r[8] = (t6 >>> 8 | t7 << 8) & 8191;
        this.r[9] = t7 >>> 5 & 127;
        this.pad[0] = key[16] & 255 | (key[17] & 255) << 8;
        this.pad[1] = key[18] & 255 | (key[19] & 255) << 8;
        this.pad[2] = key[20] & 255 | (key[21] & 255) << 8;
        this.pad[3] = key[22] & 255 | (key[23] & 255) << 8;
        this.pad[4] = key[24] & 255 | (key[25] & 255) << 8;
        this.pad[5] = key[26] & 255 | (key[27] & 255) << 8;
        this.pad[6] = key[28] & 255 | (key[29] & 255) << 8;
        this.pad[7] = key[30] & 255 | (key[31] & 255) << 8;
      };
      poly1305.prototype.blocks = function(m, mpos, bytes) {
        var hibit = this.fin ? 0 : 1 << 11;
        var t0, t1, t2, t3, t4, t5, t6, t7, c;
        var d0, d1, d2, d3, d4, d5, d6, d7, d8, d9;
        var h0 = this.h[0], h1 = this.h[1], h2 = this.h[2], h3 = this.h[3], h4 = this.h[4], h5 = this.h[5], h6 = this.h[6], h7 = this.h[7], h8 = this.h[8], h9 = this.h[9];
        var r0 = this.r[0], r1 = this.r[1], r2 = this.r[2], r3 = this.r[3], r4 = this.r[4], r5 = this.r[5], r6 = this.r[6], r7 = this.r[7], r8 = this.r[8], r9 = this.r[9];
        while (bytes >= 16) {
          t0 = m[mpos + 0] & 255 | (m[mpos + 1] & 255) << 8;
          h0 += t0 & 8191;
          t1 = m[mpos + 2] & 255 | (m[mpos + 3] & 255) << 8;
          h1 += (t0 >>> 13 | t1 << 3) & 8191;
          t2 = m[mpos + 4] & 255 | (m[mpos + 5] & 255) << 8;
          h2 += (t1 >>> 10 | t2 << 6) & 8191;
          t3 = m[mpos + 6] & 255 | (m[mpos + 7] & 255) << 8;
          h3 += (t2 >>> 7 | t3 << 9) & 8191;
          t4 = m[mpos + 8] & 255 | (m[mpos + 9] & 255) << 8;
          h4 += (t3 >>> 4 | t4 << 12) & 8191;
          h5 += t4 >>> 1 & 8191;
          t5 = m[mpos + 10] & 255 | (m[mpos + 11] & 255) << 8;
          h6 += (t4 >>> 14 | t5 << 2) & 8191;
          t6 = m[mpos + 12] & 255 | (m[mpos + 13] & 255) << 8;
          h7 += (t5 >>> 11 | t6 << 5) & 8191;
          t7 = m[mpos + 14] & 255 | (m[mpos + 15] & 255) << 8;
          h8 += (t6 >>> 8 | t7 << 8) & 8191;
          h9 += t7 >>> 5 | hibit;
          c = 0;
          d0 = c;
          d0 += h0 * r0;
          d0 += h1 * (5 * r9);
          d0 += h2 * (5 * r8);
          d0 += h3 * (5 * r7);
          d0 += h4 * (5 * r6);
          c = d0 >>> 13;
          d0 &= 8191;
          d0 += h5 * (5 * r5);
          d0 += h6 * (5 * r4);
          d0 += h7 * (5 * r3);
          d0 += h8 * (5 * r2);
          d0 += h9 * (5 * r1);
          c += d0 >>> 13;
          d0 &= 8191;
          d1 = c;
          d1 += h0 * r1;
          d1 += h1 * r0;
          d1 += h2 * (5 * r9);
          d1 += h3 * (5 * r8);
          d1 += h4 * (5 * r7);
          c = d1 >>> 13;
          d1 &= 8191;
          d1 += h5 * (5 * r6);
          d1 += h6 * (5 * r5);
          d1 += h7 * (5 * r4);
          d1 += h8 * (5 * r3);
          d1 += h9 * (5 * r2);
          c += d1 >>> 13;
          d1 &= 8191;
          d2 = c;
          d2 += h0 * r2;
          d2 += h1 * r1;
          d2 += h2 * r0;
          d2 += h3 * (5 * r9);
          d2 += h4 * (5 * r8);
          c = d2 >>> 13;
          d2 &= 8191;
          d2 += h5 * (5 * r7);
          d2 += h6 * (5 * r6);
          d2 += h7 * (5 * r5);
          d2 += h8 * (5 * r4);
          d2 += h9 * (5 * r3);
          c += d2 >>> 13;
          d2 &= 8191;
          d3 = c;
          d3 += h0 * r3;
          d3 += h1 * r2;
          d3 += h2 * r1;
          d3 += h3 * r0;
          d3 += h4 * (5 * r9);
          c = d3 >>> 13;
          d3 &= 8191;
          d3 += h5 * (5 * r8);
          d3 += h6 * (5 * r7);
          d3 += h7 * (5 * r6);
          d3 += h8 * (5 * r5);
          d3 += h9 * (5 * r4);
          c += d3 >>> 13;
          d3 &= 8191;
          d4 = c;
          d4 += h0 * r4;
          d4 += h1 * r3;
          d4 += h2 * r2;
          d4 += h3 * r1;
          d4 += h4 * r0;
          c = d4 >>> 13;
          d4 &= 8191;
          d4 += h5 * (5 * r9);
          d4 += h6 * (5 * r8);
          d4 += h7 * (5 * r7);
          d4 += h8 * (5 * r6);
          d4 += h9 * (5 * r5);
          c += d4 >>> 13;
          d4 &= 8191;
          d5 = c;
          d5 += h0 * r5;
          d5 += h1 * r4;
          d5 += h2 * r3;
          d5 += h3 * r2;
          d5 += h4 * r1;
          c = d5 >>> 13;
          d5 &= 8191;
          d5 += h5 * r0;
          d5 += h6 * (5 * r9);
          d5 += h7 * (5 * r8);
          d5 += h8 * (5 * r7);
          d5 += h9 * (5 * r6);
          c += d5 >>> 13;
          d5 &= 8191;
          d6 = c;
          d6 += h0 * r6;
          d6 += h1 * r5;
          d6 += h2 * r4;
          d6 += h3 * r3;
          d6 += h4 * r2;
          c = d6 >>> 13;
          d6 &= 8191;
          d6 += h5 * r1;
          d6 += h6 * r0;
          d6 += h7 * (5 * r9);
          d6 += h8 * (5 * r8);
          d6 += h9 * (5 * r7);
          c += d6 >>> 13;
          d6 &= 8191;
          d7 = c;
          d7 += h0 * r7;
          d7 += h1 * r6;
          d7 += h2 * r5;
          d7 += h3 * r4;
          d7 += h4 * r3;
          c = d7 >>> 13;
          d7 &= 8191;
          d7 += h5 * r2;
          d7 += h6 * r1;
          d7 += h7 * r0;
          d7 += h8 * (5 * r9);
          d7 += h9 * (5 * r8);
          c += d7 >>> 13;
          d7 &= 8191;
          d8 = c;
          d8 += h0 * r8;
          d8 += h1 * r7;
          d8 += h2 * r6;
          d8 += h3 * r5;
          d8 += h4 * r4;
          c = d8 >>> 13;
          d8 &= 8191;
          d8 += h5 * r3;
          d8 += h6 * r2;
          d8 += h7 * r1;
          d8 += h8 * r0;
          d8 += h9 * (5 * r9);
          c += d8 >>> 13;
          d8 &= 8191;
          d9 = c;
          d9 += h0 * r9;
          d9 += h1 * r8;
          d9 += h2 * r7;
          d9 += h3 * r6;
          d9 += h4 * r5;
          c = d9 >>> 13;
          d9 &= 8191;
          d9 += h5 * r4;
          d9 += h6 * r3;
          d9 += h7 * r2;
          d9 += h8 * r1;
          d9 += h9 * r0;
          c += d9 >>> 13;
          d9 &= 8191;
          c = (c << 2) + c | 0;
          c = c + d0 | 0;
          d0 = c & 8191;
          c = c >>> 13;
          d1 += c;
          h0 = d0;
          h1 = d1;
          h2 = d2;
          h3 = d3;
          h4 = d4;
          h5 = d5;
          h6 = d6;
          h7 = d7;
          h8 = d8;
          h9 = d9;
          mpos += 16;
          bytes -= 16;
        }
        this.h[0] = h0;
        this.h[1] = h1;
        this.h[2] = h2;
        this.h[3] = h3;
        this.h[4] = h4;
        this.h[5] = h5;
        this.h[6] = h6;
        this.h[7] = h7;
        this.h[8] = h8;
        this.h[9] = h9;
      };
      poly1305.prototype.finish = function(mac, macpos) {
        var g = new Uint16Array(10);
        var c, mask, f, i;
        if (this.leftover) {
          i = this.leftover;
          this.buffer[i++] = 1;
          for (; i < 16; i++) this.buffer[i] = 0;
          this.fin = 1;
          this.blocks(this.buffer, 0, 16);
        }
        c = this.h[1] >>> 13;
        this.h[1] &= 8191;
        for (i = 2; i < 10; i++) {
          this.h[i] += c;
          c = this.h[i] >>> 13;
          this.h[i] &= 8191;
        }
        this.h[0] += c * 5;
        c = this.h[0] >>> 13;
        this.h[0] &= 8191;
        this.h[1] += c;
        c = this.h[1] >>> 13;
        this.h[1] &= 8191;
        this.h[2] += c;
        g[0] = this.h[0] + 5;
        c = g[0] >>> 13;
        g[0] &= 8191;
        for (i = 1; i < 10; i++) {
          g[i] = this.h[i] + c;
          c = g[i] >>> 13;
          g[i] &= 8191;
        }
        g[9] -= 1 << 13;
        mask = (c ^ 1) - 1;
        for (i = 0; i < 10; i++) g[i] &= mask;
        mask = ~mask;
        for (i = 0; i < 10; i++) this.h[i] = this.h[i] & mask | g[i];
        this.h[0] = (this.h[0] | this.h[1] << 13) & 65535;
        this.h[1] = (this.h[1] >>> 3 | this.h[2] << 10) & 65535;
        this.h[2] = (this.h[2] >>> 6 | this.h[3] << 7) & 65535;
        this.h[3] = (this.h[3] >>> 9 | this.h[4] << 4) & 65535;
        this.h[4] = (this.h[4] >>> 12 | this.h[5] << 1 | this.h[6] << 14) & 65535;
        this.h[5] = (this.h[6] >>> 2 | this.h[7] << 11) & 65535;
        this.h[6] = (this.h[7] >>> 5 | this.h[8] << 8) & 65535;
        this.h[7] = (this.h[8] >>> 8 | this.h[9] << 5) & 65535;
        f = this.h[0] + this.pad[0];
        this.h[0] = f & 65535;
        for (i = 1; i < 8; i++) {
          f = (this.h[i] + this.pad[i] | 0) + (f >>> 16) | 0;
          this.h[i] = f & 65535;
        }
        mac[macpos + 0] = this.h[0] >>> 0 & 255;
        mac[macpos + 1] = this.h[0] >>> 8 & 255;
        mac[macpos + 2] = this.h[1] >>> 0 & 255;
        mac[macpos + 3] = this.h[1] >>> 8 & 255;
        mac[macpos + 4] = this.h[2] >>> 0 & 255;
        mac[macpos + 5] = this.h[2] >>> 8 & 255;
        mac[macpos + 6] = this.h[3] >>> 0 & 255;
        mac[macpos + 7] = this.h[3] >>> 8 & 255;
        mac[macpos + 8] = this.h[4] >>> 0 & 255;
        mac[macpos + 9] = this.h[4] >>> 8 & 255;
        mac[macpos + 10] = this.h[5] >>> 0 & 255;
        mac[macpos + 11] = this.h[5] >>> 8 & 255;
        mac[macpos + 12] = this.h[6] >>> 0 & 255;
        mac[macpos + 13] = this.h[6] >>> 8 & 255;
        mac[macpos + 14] = this.h[7] >>> 0 & 255;
        mac[macpos + 15] = this.h[7] >>> 8 & 255;
      };
      poly1305.prototype.update = function(m, mpos, bytes) {
        var i, want;
        if (this.leftover) {
          want = 16 - this.leftover;
          if (want > bytes)
            want = bytes;
          for (i = 0; i < want; i++)
            this.buffer[this.leftover + i] = m[mpos + i];
          bytes -= want;
          mpos += want;
          this.leftover += want;
          if (this.leftover < 16)
            return;
          this.blocks(this.buffer, 0, 16);
          this.leftover = 0;
        }
        if (bytes >= 16) {
          want = bytes - bytes % 16;
          this.blocks(m, mpos, want);
          mpos += want;
          bytes -= want;
        }
        if (bytes) {
          for (i = 0; i < bytes; i++)
            this.buffer[this.leftover + i] = m[mpos + i];
          this.leftover += bytes;
        }
      };
      function crypto_onetimeauth(out, outpos, m, mpos, n, k) {
        var s = new poly1305(k);
        s.update(m, mpos, n);
        s.finish(out, outpos);
        return 0;
      }
      function crypto_onetimeauth_verify(h, hpos, m, mpos, n, k) {
        var x = new Uint8Array(16);
        crypto_onetimeauth(x, 0, m, mpos, n, k);
        return crypto_verify_16(h, hpos, x, 0);
      }
      function crypto_secretbox(c, m, d, n, k) {
        var i;
        if (d < 32) return -1;
        crypto_stream_xor(c, 0, m, 0, d, n, k);
        crypto_onetimeauth(c, 16, c, 32, d - 32, c);
        for (i = 0; i < 16; i++) c[i] = 0;
        return 0;
      }
      function crypto_secretbox_open(m, c, d, n, k) {
        var i;
        var x = new Uint8Array(32);
        if (d < 32) return -1;
        crypto_stream(x, 0, 32, n, k);
        if (crypto_onetimeauth_verify(c, 16, c, 32, d - 32, x) !== 0) return -1;
        crypto_stream_xor(m, 0, c, 0, d, n, k);
        for (i = 0; i < 32; i++) m[i] = 0;
        return 0;
      }
      function set25519(r, a) {
        var i;
        for (i = 0; i < 16; i++) r[i] = a[i] | 0;
      }
      function car25519(o) {
        var i, v, c = 1;
        for (i = 0; i < 16; i++) {
          v = o[i] + c + 65535;
          c = Math.floor(v / 65536);
          o[i] = v - c * 65536;
        }
        o[0] += c - 1 + 37 * (c - 1);
      }
      function sel25519(p, q2, b) {
        var t, c = ~(b - 1);
        for (var i = 0; i < 16; i++) {
          t = c & (p[i] ^ q2[i]);
          p[i] ^= t;
          q2[i] ^= t;
        }
      }
      function pack25519(o, n) {
        var i, j, b;
        var m = gf(), t = gf();
        for (i = 0; i < 16; i++) t[i] = n[i];
        car25519(t);
        car25519(t);
        car25519(t);
        for (j = 0; j < 2; j++) {
          m[0] = t[0] - 65517;
          for (i = 1; i < 15; i++) {
            m[i] = t[i] - 65535 - (m[i - 1] >> 16 & 1);
            m[i - 1] &= 65535;
          }
          m[15] = t[15] - 32767 - (m[14] >> 16 & 1);
          b = m[15] >> 16 & 1;
          m[14] &= 65535;
          sel25519(t, m, 1 - b);
        }
        for (i = 0; i < 16; i++) {
          o[2 * i] = t[i] & 255;
          o[2 * i + 1] = t[i] >> 8;
        }
      }
      function neq25519(a, b) {
        var c = new Uint8Array(32), d = new Uint8Array(32);
        pack25519(c, a);
        pack25519(d, b);
        return crypto_verify_32(c, 0, d, 0);
      }
      function par25519(a) {
        var d = new Uint8Array(32);
        pack25519(d, a);
        return d[0] & 1;
      }
      function unpack25519(o, n) {
        var i;
        for (i = 0; i < 16; i++) o[i] = n[2 * i] + (n[2 * i + 1] << 8);
        o[15] &= 32767;
      }
      function A(o, a, b) {
        for (var i = 0; i < 16; i++) o[i] = a[i] + b[i];
      }
      function Z(o, a, b) {
        for (var i = 0; i < 16; i++) o[i] = a[i] - b[i];
      }
      function M(o, a, b) {
        var v, c, t0 = 0, t1 = 0, t2 = 0, t3 = 0, t4 = 0, t5 = 0, t6 = 0, t7 = 0, t8 = 0, t9 = 0, t10 = 0, t11 = 0, t12 = 0, t13 = 0, t14 = 0, t15 = 0, t16 = 0, t17 = 0, t18 = 0, t19 = 0, t20 = 0, t21 = 0, t22 = 0, t23 = 0, t24 = 0, t25 = 0, t26 = 0, t27 = 0, t28 = 0, t29 = 0, t30 = 0, b0 = b[0], b1 = b[1], b2 = b[2], b3 = b[3], b4 = b[4], b5 = b[5], b6 = b[6], b7 = b[7], b8 = b[8], b9 = b[9], b10 = b[10], b11 = b[11], b12 = b[12], b13 = b[13], b14 = b[14], b15 = b[15];
        v = a[0];
        t0 += v * b0;
        t1 += v * b1;
        t2 += v * b2;
        t3 += v * b3;
        t4 += v * b4;
        t5 += v * b5;
        t6 += v * b6;
        t7 += v * b7;
        t8 += v * b8;
        t9 += v * b9;
        t10 += v * b10;
        t11 += v * b11;
        t12 += v * b12;
        t13 += v * b13;
        t14 += v * b14;
        t15 += v * b15;
        v = a[1];
        t1 += v * b0;
        t2 += v * b1;
        t3 += v * b2;
        t4 += v * b3;
        t5 += v * b4;
        t6 += v * b5;
        t7 += v * b6;
        t8 += v * b7;
        t9 += v * b8;
        t10 += v * b9;
        t11 += v * b10;
        t12 += v * b11;
        t13 += v * b12;
        t14 += v * b13;
        t15 += v * b14;
        t16 += v * b15;
        v = a[2];
        t2 += v * b0;
        t3 += v * b1;
        t4 += v * b2;
        t5 += v * b3;
        t6 += v * b4;
        t7 += v * b5;
        t8 += v * b6;
        t9 += v * b7;
        t10 += v * b8;
        t11 += v * b9;
        t12 += v * b10;
        t13 += v * b11;
        t14 += v * b12;
        t15 += v * b13;
        t16 += v * b14;
        t17 += v * b15;
        v = a[3];
        t3 += v * b0;
        t4 += v * b1;
        t5 += v * b2;
        t6 += v * b3;
        t7 += v * b4;
        t8 += v * b5;
        t9 += v * b6;
        t10 += v * b7;
        t11 += v * b8;
        t12 += v * b9;
        t13 += v * b10;
        t14 += v * b11;
        t15 += v * b12;
        t16 += v * b13;
        t17 += v * b14;
        t18 += v * b15;
        v = a[4];
        t4 += v * b0;
        t5 += v * b1;
        t6 += v * b2;
        t7 += v * b3;
        t8 += v * b4;
        t9 += v * b5;
        t10 += v * b6;
        t11 += v * b7;
        t12 += v * b8;
        t13 += v * b9;
        t14 += v * b10;
        t15 += v * b11;
        t16 += v * b12;
        t17 += v * b13;
        t18 += v * b14;
        t19 += v * b15;
        v = a[5];
        t5 += v * b0;
        t6 += v * b1;
        t7 += v * b2;
        t8 += v * b3;
        t9 += v * b4;
        t10 += v * b5;
        t11 += v * b6;
        t12 += v * b7;
        t13 += v * b8;
        t14 += v * b9;
        t15 += v * b10;
        t16 += v * b11;
        t17 += v * b12;
        t18 += v * b13;
        t19 += v * b14;
        t20 += v * b15;
        v = a[6];
        t6 += v * b0;
        t7 += v * b1;
        t8 += v * b2;
        t9 += v * b3;
        t10 += v * b4;
        t11 += v * b5;
        t12 += v * b6;
        t13 += v * b7;
        t14 += v * b8;
        t15 += v * b9;
        t16 += v * b10;
        t17 += v * b11;
        t18 += v * b12;
        t19 += v * b13;
        t20 += v * b14;
        t21 += v * b15;
        v = a[7];
        t7 += v * b0;
        t8 += v * b1;
        t9 += v * b2;
        t10 += v * b3;
        t11 += v * b4;
        t12 += v * b5;
        t13 += v * b6;
        t14 += v * b7;
        t15 += v * b8;
        t16 += v * b9;
        t17 += v * b10;
        t18 += v * b11;
        t19 += v * b12;
        t20 += v * b13;
        t21 += v * b14;
        t22 += v * b15;
        v = a[8];
        t8 += v * b0;
        t9 += v * b1;
        t10 += v * b2;
        t11 += v * b3;
        t12 += v * b4;
        t13 += v * b5;
        t14 += v * b6;
        t15 += v * b7;
        t16 += v * b8;
        t17 += v * b9;
        t18 += v * b10;
        t19 += v * b11;
        t20 += v * b12;
        t21 += v * b13;
        t22 += v * b14;
        t23 += v * b15;
        v = a[9];
        t9 += v * b0;
        t10 += v * b1;
        t11 += v * b2;
        t12 += v * b3;
        t13 += v * b4;
        t14 += v * b5;
        t15 += v * b6;
        t16 += v * b7;
        t17 += v * b8;
        t18 += v * b9;
        t19 += v * b10;
        t20 += v * b11;
        t21 += v * b12;
        t22 += v * b13;
        t23 += v * b14;
        t24 += v * b15;
        v = a[10];
        t10 += v * b0;
        t11 += v * b1;
        t12 += v * b2;
        t13 += v * b3;
        t14 += v * b4;
        t15 += v * b5;
        t16 += v * b6;
        t17 += v * b7;
        t18 += v * b8;
        t19 += v * b9;
        t20 += v * b10;
        t21 += v * b11;
        t22 += v * b12;
        t23 += v * b13;
        t24 += v * b14;
        t25 += v * b15;
        v = a[11];
        t11 += v * b0;
        t12 += v * b1;
        t13 += v * b2;
        t14 += v * b3;
        t15 += v * b4;
        t16 += v * b5;
        t17 += v * b6;
        t18 += v * b7;
        t19 += v * b8;
        t20 += v * b9;
        t21 += v * b10;
        t22 += v * b11;
        t23 += v * b12;
        t24 += v * b13;
        t25 += v * b14;
        t26 += v * b15;
        v = a[12];
        t12 += v * b0;
        t13 += v * b1;
        t14 += v * b2;
        t15 += v * b3;
        t16 += v * b4;
        t17 += v * b5;
        t18 += v * b6;
        t19 += v * b7;
        t20 += v * b8;
        t21 += v * b9;
        t22 += v * b10;
        t23 += v * b11;
        t24 += v * b12;
        t25 += v * b13;
        t26 += v * b14;
        t27 += v * b15;
        v = a[13];
        t13 += v * b0;
        t14 += v * b1;
        t15 += v * b2;
        t16 += v * b3;
        t17 += v * b4;
        t18 += v * b5;
        t19 += v * b6;
        t20 += v * b7;
        t21 += v * b8;
        t22 += v * b9;
        t23 += v * b10;
        t24 += v * b11;
        t25 += v * b12;
        t26 += v * b13;
        t27 += v * b14;
        t28 += v * b15;
        v = a[14];
        t14 += v * b0;
        t15 += v * b1;
        t16 += v * b2;
        t17 += v * b3;
        t18 += v * b4;
        t19 += v * b5;
        t20 += v * b6;
        t21 += v * b7;
        t22 += v * b8;
        t23 += v * b9;
        t24 += v * b10;
        t25 += v * b11;
        t26 += v * b12;
        t27 += v * b13;
        t28 += v * b14;
        t29 += v * b15;
        v = a[15];
        t15 += v * b0;
        t16 += v * b1;
        t17 += v * b2;
        t18 += v * b3;
        t19 += v * b4;
        t20 += v * b5;
        t21 += v * b6;
        t22 += v * b7;
        t23 += v * b8;
        t24 += v * b9;
        t25 += v * b10;
        t26 += v * b11;
        t27 += v * b12;
        t28 += v * b13;
        t29 += v * b14;
        t30 += v * b15;
        t0 += 38 * t16;
        t1 += 38 * t17;
        t2 += 38 * t18;
        t3 += 38 * t19;
        t4 += 38 * t20;
        t5 += 38 * t21;
        t6 += 38 * t22;
        t7 += 38 * t23;
        t8 += 38 * t24;
        t9 += 38 * t25;
        t10 += 38 * t26;
        t11 += 38 * t27;
        t12 += 38 * t28;
        t13 += 38 * t29;
        t14 += 38 * t30;
        c = 1;
        v = t0 + c + 65535;
        c = Math.floor(v / 65536);
        t0 = v - c * 65536;
        v = t1 + c + 65535;
        c = Math.floor(v / 65536);
        t1 = v - c * 65536;
        v = t2 + c + 65535;
        c = Math.floor(v / 65536);
        t2 = v - c * 65536;
        v = t3 + c + 65535;
        c = Math.floor(v / 65536);
        t3 = v - c * 65536;
        v = t4 + c + 65535;
        c = Math.floor(v / 65536);
        t4 = v - c * 65536;
        v = t5 + c + 65535;
        c = Math.floor(v / 65536);
        t5 = v - c * 65536;
        v = t6 + c + 65535;
        c = Math.floor(v / 65536);
        t6 = v - c * 65536;
        v = t7 + c + 65535;
        c = Math.floor(v / 65536);
        t7 = v - c * 65536;
        v = t8 + c + 65535;
        c = Math.floor(v / 65536);
        t8 = v - c * 65536;
        v = t9 + c + 65535;
        c = Math.floor(v / 65536);
        t9 = v - c * 65536;
        v = t10 + c + 65535;
        c = Math.floor(v / 65536);
        t10 = v - c * 65536;
        v = t11 + c + 65535;
        c = Math.floor(v / 65536);
        t11 = v - c * 65536;
        v = t12 + c + 65535;
        c = Math.floor(v / 65536);
        t12 = v - c * 65536;
        v = t13 + c + 65535;
        c = Math.floor(v / 65536);
        t13 = v - c * 65536;
        v = t14 + c + 65535;
        c = Math.floor(v / 65536);
        t14 = v - c * 65536;
        v = t15 + c + 65535;
        c = Math.floor(v / 65536);
        t15 = v - c * 65536;
        t0 += c - 1 + 37 * (c - 1);
        c = 1;
        v = t0 + c + 65535;
        c = Math.floor(v / 65536);
        t0 = v - c * 65536;
        v = t1 + c + 65535;
        c = Math.floor(v / 65536);
        t1 = v - c * 65536;
        v = t2 + c + 65535;
        c = Math.floor(v / 65536);
        t2 = v - c * 65536;
        v = t3 + c + 65535;
        c = Math.floor(v / 65536);
        t3 = v - c * 65536;
        v = t4 + c + 65535;
        c = Math.floor(v / 65536);
        t4 = v - c * 65536;
        v = t5 + c + 65535;
        c = Math.floor(v / 65536);
        t5 = v - c * 65536;
        v = t6 + c + 65535;
        c = Math.floor(v / 65536);
        t6 = v - c * 65536;
        v = t7 + c + 65535;
        c = Math.floor(v / 65536);
        t7 = v - c * 65536;
        v = t8 + c + 65535;
        c = Math.floor(v / 65536);
        t8 = v - c * 65536;
        v = t9 + c + 65535;
        c = Math.floor(v / 65536);
        t9 = v - c * 65536;
        v = t10 + c + 65535;
        c = Math.floor(v / 65536);
        t10 = v - c * 65536;
        v = t11 + c + 65535;
        c = Math.floor(v / 65536);
        t11 = v - c * 65536;
        v = t12 + c + 65535;
        c = Math.floor(v / 65536);
        t12 = v - c * 65536;
        v = t13 + c + 65535;
        c = Math.floor(v / 65536);
        t13 = v - c * 65536;
        v = t14 + c + 65535;
        c = Math.floor(v / 65536);
        t14 = v - c * 65536;
        v = t15 + c + 65535;
        c = Math.floor(v / 65536);
        t15 = v - c * 65536;
        t0 += c - 1 + 37 * (c - 1);
        o[0] = t0;
        o[1] = t1;
        o[2] = t2;
        o[3] = t3;
        o[4] = t4;
        o[5] = t5;
        o[6] = t6;
        o[7] = t7;
        o[8] = t8;
        o[9] = t9;
        o[10] = t10;
        o[11] = t11;
        o[12] = t12;
        o[13] = t13;
        o[14] = t14;
        o[15] = t15;
      }
      function S(o, a) {
        M(o, a, a);
      }
      function inv25519(o, i) {
        var c = gf();
        var a;
        for (a = 0; a < 16; a++) c[a] = i[a];
        for (a = 253; a >= 0; a--) {
          S(c, c);
          if (a !== 2 && a !== 4) M(c, c, i);
        }
        for (a = 0; a < 16; a++) o[a] = c[a];
      }
      function pow2523(o, i) {
        var c = gf();
        var a;
        for (a = 0; a < 16; a++) c[a] = i[a];
        for (a = 250; a >= 0; a--) {
          S(c, c);
          if (a !== 1) M(c, c, i);
        }
        for (a = 0; a < 16; a++) o[a] = c[a];
      }
      function crypto_scalarmult(q2, n, p) {
        var z = new Uint8Array(32);
        var x = new Float64Array(80), r, i;
        var a = gf(), b = gf(), c = gf(), d = gf(), e = gf(), f = gf();
        for (i = 0; i < 31; i++) z[i] = n[i];
        z[31] = n[31] & 127 | 64;
        z[0] &= 248;
        unpack25519(x, p);
        for (i = 0; i < 16; i++) {
          b[i] = x[i];
          d[i] = a[i] = c[i] = 0;
        }
        a[0] = d[0] = 1;
        for (i = 254; i >= 0; --i) {
          r = z[i >>> 3] >>> (i & 7) & 1;
          sel25519(a, b, r);
          sel25519(c, d, r);
          A(e, a, c);
          Z(a, a, c);
          A(c, b, d);
          Z(b, b, d);
          S(d, e);
          S(f, a);
          M(a, c, a);
          M(c, b, e);
          A(e, a, c);
          Z(a, a, c);
          S(b, a);
          Z(c, d, f);
          M(a, c, _121665);
          A(a, a, d);
          M(c, c, a);
          M(a, d, f);
          M(d, b, x);
          S(b, e);
          sel25519(a, b, r);
          sel25519(c, d, r);
        }
        for (i = 0; i < 16; i++) {
          x[i + 16] = a[i];
          x[i + 32] = c[i];
          x[i + 48] = b[i];
          x[i + 64] = d[i];
        }
        var x32 = x.subarray(32);
        var x16 = x.subarray(16);
        inv25519(x32, x32);
        M(x16, x16, x32);
        pack25519(q2, x16);
        return 0;
      }
      function crypto_scalarmult_base(q2, n) {
        return crypto_scalarmult(q2, n, _9);
      }
      function crypto_box_keypair(y, x) {
        randombytes(x, 32);
        return crypto_scalarmult_base(y, x);
      }
      function crypto_box_beforenm(k, y, x) {
        var s = new Uint8Array(32);
        crypto_scalarmult(s, x, y);
        return crypto_core_hsalsa20(k, _0, s, sigma);
      }
      var crypto_box_afternm = crypto_secretbox;
      var crypto_box_open_afternm = crypto_secretbox_open;
      function crypto_box(c, m, d, n, y, x) {
        var k = new Uint8Array(32);
        crypto_box_beforenm(k, y, x);
        return crypto_box_afternm(c, m, d, n, k);
      }
      function crypto_box_open(m, c, d, n, y, x) {
        var k = new Uint8Array(32);
        crypto_box_beforenm(k, y, x);
        return crypto_box_open_afternm(m, c, d, n, k);
      }
      var K = [
        1116352408,
        3609767458,
        1899447441,
        602891725,
        3049323471,
        3964484399,
        3921009573,
        2173295548,
        961987163,
        4081628472,
        1508970993,
        3053834265,
        2453635748,
        2937671579,
        2870763221,
        3664609560,
        3624381080,
        2734883394,
        310598401,
        1164996542,
        607225278,
        1323610764,
        1426881987,
        3590304994,
        1925078388,
        4068182383,
        2162078206,
        991336113,
        2614888103,
        633803317,
        3248222580,
        3479774868,
        3835390401,
        2666613458,
        4022224774,
        944711139,
        264347078,
        2341262773,
        604807628,
        2007800933,
        770255983,
        1495990901,
        1249150122,
        1856431235,
        1555081692,
        3175218132,
        1996064986,
        2198950837,
        2554220882,
        3999719339,
        2821834349,
        766784016,
        2952996808,
        2566594879,
        3210313671,
        3203337956,
        3336571891,
        1034457026,
        3584528711,
        2466948901,
        113926993,
        3758326383,
        338241895,
        168717936,
        666307205,
        1188179964,
        773529912,
        1546045734,
        1294757372,
        1522805485,
        1396182291,
        2643833823,
        1695183700,
        2343527390,
        1986661051,
        1014477480,
        2177026350,
        1206759142,
        2456956037,
        344077627,
        2730485921,
        1290863460,
        2820302411,
        3158454273,
        3259730800,
        3505952657,
        3345764771,
        106217008,
        3516065817,
        3606008344,
        3600352804,
        1432725776,
        4094571909,
        1467031594,
        275423344,
        851169720,
        430227734,
        3100823752,
        506948616,
        1363258195,
        659060556,
        3750685593,
        883997877,
        3785050280,
        958139571,
        3318307427,
        1322822218,
        3812723403,
        1537002063,
        2003034995,
        1747873779,
        3602036899,
        1955562222,
        1575990012,
        2024104815,
        1125592928,
        2227730452,
        2716904306,
        2361852424,
        442776044,
        2428436474,
        593698344,
        2756734187,
        3733110249,
        3204031479,
        2999351573,
        3329325298,
        3815920427,
        3391569614,
        3928383900,
        3515267271,
        566280711,
        3940187606,
        3454069534,
        4118630271,
        4000239992,
        116418474,
        1914138554,
        174292421,
        2731055270,
        289380356,
        3203993006,
        460393269,
        320620315,
        685471733,
        587496836,
        852142971,
        1086792851,
        1017036298,
        365543100,
        1126000580,
        2618297676,
        1288033470,
        3409855158,
        1501505948,
        4234509866,
        1607167915,
        987167468,
        1816402316,
        1246189591
      ];
      function crypto_hashblocks_hl(hh, hl, m, n) {
        var wh = new Int32Array(16), wl = new Int32Array(16), bh0, bh1, bh2, bh3, bh4, bh5, bh6, bh7, bl0, bl1, bl2, bl3, bl4, bl5, bl6, bl7, th, tl, i, j, h, l, a, b, c, d;
        var ah0 = hh[0], ah1 = hh[1], ah2 = hh[2], ah3 = hh[3], ah4 = hh[4], ah5 = hh[5], ah6 = hh[6], ah7 = hh[7], al0 = hl[0], al1 = hl[1], al2 = hl[2], al3 = hl[3], al4 = hl[4], al5 = hl[5], al6 = hl[6], al7 = hl[7];
        var pos = 0;
        while (n >= 128) {
          for (i = 0; i < 16; i++) {
            j = 8 * i + pos;
            wh[i] = m[j + 0] << 24 | m[j + 1] << 16 | m[j + 2] << 8 | m[j + 3];
            wl[i] = m[j + 4] << 24 | m[j + 5] << 16 | m[j + 6] << 8 | m[j + 7];
          }
          for (i = 0; i < 80; i++) {
            bh0 = ah0;
            bh1 = ah1;
            bh2 = ah2;
            bh3 = ah3;
            bh4 = ah4;
            bh5 = ah5;
            bh6 = ah6;
            bh7 = ah7;
            bl0 = al0;
            bl1 = al1;
            bl2 = al2;
            bl3 = al3;
            bl4 = al4;
            bl5 = al5;
            bl6 = al6;
            bl7 = al7;
            h = ah7;
            l = al7;
            a = l & 65535;
            b = l >>> 16;
            c = h & 65535;
            d = h >>> 16;
            h = (ah4 >>> 14 | al4 << 32 - 14) ^ (ah4 >>> 18 | al4 << 32 - 18) ^ (al4 >>> 41 - 32 | ah4 << 32 - (41 - 32));
            l = (al4 >>> 14 | ah4 << 32 - 14) ^ (al4 >>> 18 | ah4 << 32 - 18) ^ (ah4 >>> 41 - 32 | al4 << 32 - (41 - 32));
            a += l & 65535;
            b += l >>> 16;
            c += h & 65535;
            d += h >>> 16;
            h = ah4 & ah5 ^ ~ah4 & ah6;
            l = al4 & al5 ^ ~al4 & al6;
            a += l & 65535;
            b += l >>> 16;
            c += h & 65535;
            d += h >>> 16;
            h = K[i * 2];
            l = K[i * 2 + 1];
            a += l & 65535;
            b += l >>> 16;
            c += h & 65535;
            d += h >>> 16;
            h = wh[i % 16];
            l = wl[i % 16];
            a += l & 65535;
            b += l >>> 16;
            c += h & 65535;
            d += h >>> 16;
            b += a >>> 16;
            c += b >>> 16;
            d += c >>> 16;
            th = c & 65535 | d << 16;
            tl = a & 65535 | b << 16;
            h = th;
            l = tl;
            a = l & 65535;
            b = l >>> 16;
            c = h & 65535;
            d = h >>> 16;
            h = (ah0 >>> 28 | al0 << 32 - 28) ^ (al0 >>> 34 - 32 | ah0 << 32 - (34 - 32)) ^ (al0 >>> 39 - 32 | ah0 << 32 - (39 - 32));
            l = (al0 >>> 28 | ah0 << 32 - 28) ^ (ah0 >>> 34 - 32 | al0 << 32 - (34 - 32)) ^ (ah0 >>> 39 - 32 | al0 << 32 - (39 - 32));
            a += l & 65535;
            b += l >>> 16;
            c += h & 65535;
            d += h >>> 16;
            h = ah0 & ah1 ^ ah0 & ah2 ^ ah1 & ah2;
            l = al0 & al1 ^ al0 & al2 ^ al1 & al2;
            a += l & 65535;
            b += l >>> 16;
            c += h & 65535;
            d += h >>> 16;
            b += a >>> 16;
            c += b >>> 16;
            d += c >>> 16;
            bh7 = c & 65535 | d << 16;
            bl7 = a & 65535 | b << 16;
            h = bh3;
            l = bl3;
            a = l & 65535;
            b = l >>> 16;
            c = h & 65535;
            d = h >>> 16;
            h = th;
            l = tl;
            a += l & 65535;
            b += l >>> 16;
            c += h & 65535;
            d += h >>> 16;
            b += a >>> 16;
            c += b >>> 16;
            d += c >>> 16;
            bh3 = c & 65535 | d << 16;
            bl3 = a & 65535 | b << 16;
            ah1 = bh0;
            ah2 = bh1;
            ah3 = bh2;
            ah4 = bh3;
            ah5 = bh4;
            ah6 = bh5;
            ah7 = bh6;
            ah0 = bh7;
            al1 = bl0;
            al2 = bl1;
            al3 = bl2;
            al4 = bl3;
            al5 = bl4;
            al6 = bl5;
            al7 = bl6;
            al0 = bl7;
            if (i % 16 === 15) {
              for (j = 0; j < 16; j++) {
                h = wh[j];
                l = wl[j];
                a = l & 65535;
                b = l >>> 16;
                c = h & 65535;
                d = h >>> 16;
                h = wh[(j + 9) % 16];
                l = wl[(j + 9) % 16];
                a += l & 65535;
                b += l >>> 16;
                c += h & 65535;
                d += h >>> 16;
                th = wh[(j + 1) % 16];
                tl = wl[(j + 1) % 16];
                h = (th >>> 1 | tl << 32 - 1) ^ (th >>> 8 | tl << 32 - 8) ^ th >>> 7;
                l = (tl >>> 1 | th << 32 - 1) ^ (tl >>> 8 | th << 32 - 8) ^ (tl >>> 7 | th << 32 - 7);
                a += l & 65535;
                b += l >>> 16;
                c += h & 65535;
                d += h >>> 16;
                th = wh[(j + 14) % 16];
                tl = wl[(j + 14) % 16];
                h = (th >>> 19 | tl << 32 - 19) ^ (tl >>> 61 - 32 | th << 32 - (61 - 32)) ^ th >>> 6;
                l = (tl >>> 19 | th << 32 - 19) ^ (th >>> 61 - 32 | tl << 32 - (61 - 32)) ^ (tl >>> 6 | th << 32 - 6);
                a += l & 65535;
                b += l >>> 16;
                c += h & 65535;
                d += h >>> 16;
                b += a >>> 16;
                c += b >>> 16;
                d += c >>> 16;
                wh[j] = c & 65535 | d << 16;
                wl[j] = a & 65535 | b << 16;
              }
            }
          }
          h = ah0;
          l = al0;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[0];
          l = hl[0];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[0] = ah0 = c & 65535 | d << 16;
          hl[0] = al0 = a & 65535 | b << 16;
          h = ah1;
          l = al1;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[1];
          l = hl[1];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[1] = ah1 = c & 65535 | d << 16;
          hl[1] = al1 = a & 65535 | b << 16;
          h = ah2;
          l = al2;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[2];
          l = hl[2];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[2] = ah2 = c & 65535 | d << 16;
          hl[2] = al2 = a & 65535 | b << 16;
          h = ah3;
          l = al3;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[3];
          l = hl[3];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[3] = ah3 = c & 65535 | d << 16;
          hl[3] = al3 = a & 65535 | b << 16;
          h = ah4;
          l = al4;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[4];
          l = hl[4];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[4] = ah4 = c & 65535 | d << 16;
          hl[4] = al4 = a & 65535 | b << 16;
          h = ah5;
          l = al5;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[5];
          l = hl[5];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[5] = ah5 = c & 65535 | d << 16;
          hl[5] = al5 = a & 65535 | b << 16;
          h = ah6;
          l = al6;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[6];
          l = hl[6];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[6] = ah6 = c & 65535 | d << 16;
          hl[6] = al6 = a & 65535 | b << 16;
          h = ah7;
          l = al7;
          a = l & 65535;
          b = l >>> 16;
          c = h & 65535;
          d = h >>> 16;
          h = hh[7];
          l = hl[7];
          a += l & 65535;
          b += l >>> 16;
          c += h & 65535;
          d += h >>> 16;
          b += a >>> 16;
          c += b >>> 16;
          d += c >>> 16;
          hh[7] = ah7 = c & 65535 | d << 16;
          hl[7] = al7 = a & 65535 | b << 16;
          pos += 128;
          n -= 128;
        }
        return n;
      }
      function crypto_hash(out, m, n) {
        var hh = new Int32Array(8), hl = new Int32Array(8), x = new Uint8Array(256), i, b = n;
        hh[0] = 1779033703;
        hh[1] = 3144134277;
        hh[2] = 1013904242;
        hh[3] = 2773480762;
        hh[4] = 1359893119;
        hh[5] = 2600822924;
        hh[6] = 528734635;
        hh[7] = 1541459225;
        hl[0] = 4089235720;
        hl[1] = 2227873595;
        hl[2] = 4271175723;
        hl[3] = 1595750129;
        hl[4] = 2917565137;
        hl[5] = 725511199;
        hl[6] = 4215389547;
        hl[7] = 327033209;
        crypto_hashblocks_hl(hh, hl, m, n);
        n %= 128;
        for (i = 0; i < n; i++) x[i] = m[b - n + i];
        x[n] = 128;
        n = 256 - 128 * (n < 112 ? 1 : 0);
        x[n - 9] = 0;
        ts64(x, n - 8, b / 536870912 | 0, b << 3);
        crypto_hashblocks_hl(hh, hl, x, n);
        for (i = 0; i < 8; i++) ts64(out, 8 * i, hh[i], hl[i]);
        return 0;
      }
      function add(p, q2) {
        var a = gf(), b = gf(), c = gf(), d = gf(), e = gf(), f = gf(), g = gf(), h = gf(), t = gf();
        Z(a, p[1], p[0]);
        Z(t, q2[1], q2[0]);
        M(a, a, t);
        A(b, p[0], p[1]);
        A(t, q2[0], q2[1]);
        M(b, b, t);
        M(c, p[3], q2[3]);
        M(c, c, D2);
        M(d, p[2], q2[2]);
        A(d, d, d);
        Z(e, b, a);
        Z(f, d, c);
        A(g, d, c);
        A(h, b, a);
        M(p[0], e, f);
        M(p[1], h, g);
        M(p[2], g, f);
        M(p[3], e, h);
      }
      function cswap(p, q2, b) {
        var i;
        for (i = 0; i < 4; i++) {
          sel25519(p[i], q2[i], b);
        }
      }
      function pack(r, p) {
        var tx = gf(), ty = gf(), zi = gf();
        inv25519(zi, p[2]);
        M(tx, p[0], zi);
        M(ty, p[1], zi);
        pack25519(r, ty);
        r[31] ^= par25519(tx) << 7;
      }
      function scalarmult(p, q2, s) {
        var b, i;
        set25519(p[0], gf0);
        set25519(p[1], gf1);
        set25519(p[2], gf1);
        set25519(p[3], gf0);
        for (i = 255; i >= 0; --i) {
          b = s[i / 8 | 0] >> (i & 7) & 1;
          cswap(p, q2, b);
          add(q2, p);
          add(p, p);
          cswap(p, q2, b);
        }
      }
      function scalarbase(p, s) {
        var q2 = [gf(), gf(), gf(), gf()];
        set25519(q2[0], X);
        set25519(q2[1], Y);
        set25519(q2[2], gf1);
        M(q2[3], X, Y);
        scalarmult(p, q2, s);
      }
      function crypto_sign_keypair(pk, sk, seeded) {
        var d = new Uint8Array(64);
        var p = [gf(), gf(), gf(), gf()];
        var i;
        if (!seeded) randombytes(sk, 32);
        crypto_hash(d, sk, 32);
        d[0] &= 248;
        d[31] &= 127;
        d[31] |= 64;
        scalarbase(p, d);
        pack(pk, p);
        for (i = 0; i < 32; i++) sk[i + 32] = pk[i];
        return 0;
      }
      var L = new Float64Array([237, 211, 245, 92, 26, 99, 18, 88, 214, 156, 247, 162, 222, 249, 222, 20, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 16]);
      function modL(r, x) {
        var carry, i, j, k;
        for (i = 63; i >= 32; --i) {
          carry = 0;
          for (j = i - 32, k = i - 12; j < k; ++j) {
            x[j] += carry - 16 * x[i] * L[j - (i - 32)];
            carry = Math.floor((x[j] + 128) / 256);
            x[j] -= carry * 256;
          }
          x[j] += carry;
          x[i] = 0;
        }
        carry = 0;
        for (j = 0; j < 32; j++) {
          x[j] += carry - (x[31] >> 4) * L[j];
          carry = x[j] >> 8;
          x[j] &= 255;
        }
        for (j = 0; j < 32; j++) x[j] -= carry * L[j];
        for (i = 0; i < 32; i++) {
          x[i + 1] += x[i] >> 8;
          r[i] = x[i] & 255;
        }
      }
      function reduce(r) {
        var x = new Float64Array(64), i;
        for (i = 0; i < 64; i++) x[i] = r[i];
        for (i = 0; i < 64; i++) r[i] = 0;
        modL(r, x);
      }
      function crypto_sign(sm, m, n, sk) {
        var d = new Uint8Array(64), h = new Uint8Array(64), r = new Uint8Array(64);
        var i, j, x = new Float64Array(64);
        var p = [gf(), gf(), gf(), gf()];
        crypto_hash(d, sk, 32);
        d[0] &= 248;
        d[31] &= 127;
        d[31] |= 64;
        var smlen = n + 64;
        for (i = 0; i < n; i++) sm[64 + i] = m[i];
        for (i = 0; i < 32; i++) sm[32 + i] = d[32 + i];
        crypto_hash(r, sm.subarray(32), n + 32);
        reduce(r);
        scalarbase(p, r);
        pack(sm, p);
        for (i = 32; i < 64; i++) sm[i] = sk[i];
        crypto_hash(h, sm, n + 64);
        reduce(h);
        for (i = 0; i < 64; i++) x[i] = 0;
        for (i = 0; i < 32; i++) x[i] = r[i];
        for (i = 0; i < 32; i++) {
          for (j = 0; j < 32; j++) {
            x[i + j] += h[i] * d[j];
          }
        }
        modL(sm.subarray(32), x);
        return smlen;
      }
      function unpackneg(r, p) {
        var t = gf(), chk = gf(), num = gf(), den = gf(), den2 = gf(), den4 = gf(), den6 = gf();
        set25519(r[2], gf1);
        unpack25519(r[1], p);
        S(num, r[1]);
        M(den, num, D);
        Z(num, num, r[2]);
        A(den, r[2], den);
        S(den2, den);
        S(den4, den2);
        M(den6, den4, den2);
        M(t, den6, num);
        M(t, t, den);
        pow2523(t, t);
        M(t, t, num);
        M(t, t, den);
        M(t, t, den);
        M(r[0], t, den);
        S(chk, r[0]);
        M(chk, chk, den);
        if (neq25519(chk, num)) M(r[0], r[0], I);
        S(chk, r[0]);
        M(chk, chk, den);
        if (neq25519(chk, num)) return -1;
        if (par25519(r[0]) === p[31] >> 7) Z(r[0], gf0, r[0]);
        M(r[3], r[0], r[1]);
        return 0;
      }
      function crypto_sign_open(m, sm, n, pk) {
        var i;
        var t = new Uint8Array(32), h = new Uint8Array(64);
        var p = [gf(), gf(), gf(), gf()], q2 = [gf(), gf(), gf(), gf()];
        if (n < 64) return -1;
        if (unpackneg(q2, pk)) return -1;
        for (i = 0; i < n; i++) m[i] = sm[i];
        for (i = 0; i < 32; i++) m[i + 32] = pk[i];
        crypto_hash(h, m, n);
        reduce(h);
        scalarmult(p, q2, h);
        scalarbase(q2, sm.subarray(32));
        add(p, q2);
        pack(t, p);
        n -= 64;
        if (crypto_verify_32(sm, 0, t, 0)) {
          for (i = 0; i < n; i++) m[i] = 0;
          return -1;
        }
        for (i = 0; i < n; i++) m[i] = sm[i + 64];
        return n;
      }
      var crypto_secretbox_KEYBYTES = 32, crypto_secretbox_NONCEBYTES = 24, crypto_secretbox_ZEROBYTES = 32, crypto_secretbox_BOXZEROBYTES = 16, crypto_scalarmult_BYTES = 32, crypto_scalarmult_SCALARBYTES = 32, crypto_box_PUBLICKEYBYTES = 32, crypto_box_SECRETKEYBYTES = 32, crypto_box_BEFORENMBYTES = 32, crypto_box_NONCEBYTES = crypto_secretbox_NONCEBYTES, crypto_box_ZEROBYTES = crypto_secretbox_ZEROBYTES, crypto_box_BOXZEROBYTES = crypto_secretbox_BOXZEROBYTES, crypto_sign_BYTES = 64, crypto_sign_PUBLICKEYBYTES = 32, crypto_sign_SECRETKEYBYTES = 64, crypto_sign_SEEDBYTES = 32, crypto_hash_BYTES = 64;
      nacl2.lowlevel = {
        crypto_core_hsalsa20,
        crypto_stream_xor,
        crypto_stream,
        crypto_stream_salsa20_xor,
        crypto_stream_salsa20,
        crypto_onetimeauth,
        crypto_onetimeauth_verify,
        crypto_verify_16,
        crypto_verify_32,
        crypto_secretbox,
        crypto_secretbox_open,
        crypto_scalarmult,
        crypto_scalarmult_base,
        crypto_box_beforenm,
        crypto_box_afternm,
        crypto_box,
        crypto_box_open,
        crypto_box_keypair,
        crypto_hash,
        crypto_sign,
        crypto_sign_keypair,
        crypto_sign_open,
        crypto_secretbox_KEYBYTES,
        crypto_secretbox_NONCEBYTES,
        crypto_secretbox_ZEROBYTES,
        crypto_secretbox_BOXZEROBYTES,
        crypto_scalarmult_BYTES,
        crypto_scalarmult_SCALARBYTES,
        crypto_box_PUBLICKEYBYTES,
        crypto_box_SECRETKEYBYTES,
        crypto_box_BEFORENMBYTES,
        crypto_box_NONCEBYTES,
        crypto_box_ZEROBYTES,
        crypto_box_BOXZEROBYTES,
        crypto_sign_BYTES,
        crypto_sign_PUBLICKEYBYTES,
        crypto_sign_SECRETKEYBYTES,
        crypto_sign_SEEDBYTES,
        crypto_hash_BYTES,
        gf,
        D,
        L,
        pack25519,
        unpack25519,
        M,
        A,
        S,
        Z,
        pow2523,
        add,
        set25519,
        modL,
        scalarmult,
        scalarbase
      };
      function checkLengths(k, n) {
        if (k.length !== crypto_secretbox_KEYBYTES) throw new Error("bad key size");
        if (n.length !== crypto_secretbox_NONCEBYTES) throw new Error("bad nonce size");
      }
      function checkBoxLengths(pk, sk) {
        if (pk.length !== crypto_box_PUBLICKEYBYTES) throw new Error("bad public key size");
        if (sk.length !== crypto_box_SECRETKEYBYTES) throw new Error("bad secret key size");
      }
      function checkArrayTypes() {
        for (var i = 0; i < arguments.length; i++) {
          if (!(arguments[i] instanceof Uint8Array))
            throw new TypeError("unexpected type, use Uint8Array");
        }
      }
      function cleanup(arr) {
        for (var i = 0; i < arr.length; i++) arr[i] = 0;
      }
      nacl2.randomBytes = function(n) {
        var b = new Uint8Array(n);
        randombytes(b, n);
        return b;
      };
      nacl2.secretbox = function(msg, nonce, key) {
        checkArrayTypes(msg, nonce, key);
        checkLengths(key, nonce);
        var m = new Uint8Array(crypto_secretbox_ZEROBYTES + msg.length);
        var c = new Uint8Array(m.length);
        for (var i = 0; i < msg.length; i++) m[i + crypto_secretbox_ZEROBYTES] = msg[i];
        crypto_secretbox(c, m, m.length, nonce, key);
        return c.subarray(crypto_secretbox_BOXZEROBYTES);
      };
      nacl2.secretbox.open = function(box, nonce, key) {
        checkArrayTypes(box, nonce, key);
        checkLengths(key, nonce);
        var c = new Uint8Array(crypto_secretbox_BOXZEROBYTES + box.length);
        var m = new Uint8Array(c.length);
        for (var i = 0; i < box.length; i++) c[i + crypto_secretbox_BOXZEROBYTES] = box[i];
        if (c.length < 32) return null;
        if (crypto_secretbox_open(m, c, c.length, nonce, key) !== 0) return null;
        return m.subarray(crypto_secretbox_ZEROBYTES);
      };
      nacl2.secretbox.keyLength = crypto_secretbox_KEYBYTES;
      nacl2.secretbox.nonceLength = crypto_secretbox_NONCEBYTES;
      nacl2.secretbox.overheadLength = crypto_secretbox_BOXZEROBYTES;
      nacl2.scalarMult = function(n, p) {
        checkArrayTypes(n, p);
        if (n.length !== crypto_scalarmult_SCALARBYTES) throw new Error("bad n size");
        if (p.length !== crypto_scalarmult_BYTES) throw new Error("bad p size");
        var q2 = new Uint8Array(crypto_scalarmult_BYTES);
        crypto_scalarmult(q2, n, p);
        return q2;
      };
      nacl2.scalarMult.base = function(n) {
        checkArrayTypes(n);
        if (n.length !== crypto_scalarmult_SCALARBYTES) throw new Error("bad n size");
        var q2 = new Uint8Array(crypto_scalarmult_BYTES);
        crypto_scalarmult_base(q2, n);
        return q2;
      };
      nacl2.scalarMult.scalarLength = crypto_scalarmult_SCALARBYTES;
      nacl2.scalarMult.groupElementLength = crypto_scalarmult_BYTES;
      nacl2.box = function(msg, nonce, publicKey, secretKey) {
        var k = nacl2.box.before(publicKey, secretKey);
        return nacl2.secretbox(msg, nonce, k);
      };
      nacl2.box.before = function(publicKey, secretKey) {
        checkArrayTypes(publicKey, secretKey);
        checkBoxLengths(publicKey, secretKey);
        var k = new Uint8Array(crypto_box_BEFORENMBYTES);
        crypto_box_beforenm(k, publicKey, secretKey);
        return k;
      };
      nacl2.box.after = nacl2.secretbox;
      nacl2.box.open = function(msg, nonce, publicKey, secretKey) {
        var k = nacl2.box.before(publicKey, secretKey);
        return nacl2.secretbox.open(msg, nonce, k);
      };
      nacl2.box.open.after = nacl2.secretbox.open;
      nacl2.box.keyPair = function() {
        var pk = new Uint8Array(crypto_box_PUBLICKEYBYTES);
        var sk = new Uint8Array(crypto_box_SECRETKEYBYTES);
        crypto_box_keypair(pk, sk);
        return { publicKey: pk, secretKey: sk };
      };
      nacl2.box.keyPair.fromSecretKey = function(secretKey) {
        checkArrayTypes(secretKey);
        if (secretKey.length !== crypto_box_SECRETKEYBYTES)
          throw new Error("bad secret key size");
        var pk = new Uint8Array(crypto_box_PUBLICKEYBYTES);
        crypto_scalarmult_base(pk, secretKey);
        return { publicKey: pk, secretKey: new Uint8Array(secretKey) };
      };
      nacl2.box.publicKeyLength = crypto_box_PUBLICKEYBYTES;
      nacl2.box.secretKeyLength = crypto_box_SECRETKEYBYTES;
      nacl2.box.sharedKeyLength = crypto_box_BEFORENMBYTES;
      nacl2.box.nonceLength = crypto_box_NONCEBYTES;
      nacl2.box.overheadLength = nacl2.secretbox.overheadLength;
      nacl2.sign = function(msg, secretKey) {
        checkArrayTypes(msg, secretKey);
        if (secretKey.length !== crypto_sign_SECRETKEYBYTES)
          throw new Error("bad secret key size");
        var signedMsg = new Uint8Array(crypto_sign_BYTES + msg.length);
        crypto_sign(signedMsg, msg, msg.length, secretKey);
        return signedMsg;
      };
      nacl2.sign.open = function(signedMsg, publicKey) {
        checkArrayTypes(signedMsg, publicKey);
        if (publicKey.length !== crypto_sign_PUBLICKEYBYTES)
          throw new Error("bad public key size");
        var tmp = new Uint8Array(signedMsg.length);
        var mlen = crypto_sign_open(tmp, signedMsg, signedMsg.length, publicKey);
        if (mlen < 0) return null;
        var m = new Uint8Array(mlen);
        for (var i = 0; i < m.length; i++) m[i] = tmp[i];
        return m;
      };
      nacl2.sign.detached = function(msg, secretKey) {
        var signedMsg = nacl2.sign(msg, secretKey);
        var sig = new Uint8Array(crypto_sign_BYTES);
        for (var i = 0; i < sig.length; i++) sig[i] = signedMsg[i];
        return sig;
      };
      nacl2.sign.detached.verify = function(msg, sig, publicKey) {
        checkArrayTypes(msg, sig, publicKey);
        if (sig.length !== crypto_sign_BYTES)
          throw new Error("bad signature size");
        if (publicKey.length !== crypto_sign_PUBLICKEYBYTES)
          throw new Error("bad public key size");
        var sm = new Uint8Array(crypto_sign_BYTES + msg.length);
        var m = new Uint8Array(crypto_sign_BYTES + msg.length);
        var i;
        for (i = 0; i < crypto_sign_BYTES; i++) sm[i] = sig[i];
        for (i = 0; i < msg.length; i++) sm[i + crypto_sign_BYTES] = msg[i];
        return crypto_sign_open(m, sm, sm.length, publicKey) >= 0;
      };
      nacl2.sign.keyPair = function() {
        var pk = new Uint8Array(crypto_sign_PUBLICKEYBYTES);
        var sk = new Uint8Array(crypto_sign_SECRETKEYBYTES);
        crypto_sign_keypair(pk, sk);
        return { publicKey: pk, secretKey: sk };
      };
      nacl2.sign.keyPair.fromSecretKey = function(secretKey) {
        checkArrayTypes(secretKey);
        if (secretKey.length !== crypto_sign_SECRETKEYBYTES)
          throw new Error("bad secret key size");
        var pk = new Uint8Array(crypto_sign_PUBLICKEYBYTES);
        for (var i = 0; i < pk.length; i++) pk[i] = secretKey[32 + i];
        return { publicKey: pk, secretKey: new Uint8Array(secretKey) };
      };
      nacl2.sign.keyPair.fromSeed = function(seed) {
        checkArrayTypes(seed);
        if (seed.length !== crypto_sign_SEEDBYTES)
          throw new Error("bad seed size");
        var pk = new Uint8Array(crypto_sign_PUBLICKEYBYTES);
        var sk = new Uint8Array(crypto_sign_SECRETKEYBYTES);
        for (var i = 0; i < 32; i++) sk[i] = seed[i];
        crypto_sign_keypair(pk, sk, true);
        return { publicKey: pk, secretKey: sk };
      };
      nacl2.sign.publicKeyLength = crypto_sign_PUBLICKEYBYTES;
      nacl2.sign.secretKeyLength = crypto_sign_SECRETKEYBYTES;
      nacl2.sign.seedLength = crypto_sign_SEEDBYTES;
      nacl2.sign.signatureLength = crypto_sign_BYTES;
      nacl2.hash = function(msg) {
        checkArrayTypes(msg);
        var h = new Uint8Array(crypto_hash_BYTES);
        crypto_hash(h, msg, msg.length);
        return h;
      };
      nacl2.hash.hashLength = crypto_hash_BYTES;
      nacl2.verify = function(x, y) {
        checkArrayTypes(x, y);
        if (x.length === 0 || y.length === 0) return false;
        if (x.length !== y.length) return false;
        return vn(x, 0, y, 0, x.length) === 0 ? true : false;
      };
      nacl2.setPRNG = function(fn) {
        randombytes = fn;
      };
      (function() {
        var crypto = typeof self !== "undefined" ? self.crypto || self.msCrypto : null;
        if (crypto && crypto.getRandomValues) {
          var QUOTA = 65536;
          nacl2.setPRNG(function(x, n) {
            var i, v = new Uint8Array(n);
            for (i = 0; i < n; i += QUOTA) {
              crypto.getRandomValues(v.subarray(i, i + Math.min(n - i, QUOTA)));
            }
            for (i = 0; i < n; i++) x[i] = v[i];
            cleanup(v);
          });
        } else if (typeof require !== "undefined") {
          crypto = require_crypto();
          if (crypto && crypto.randomBytes) {
            nacl2.setPRNG(function(x, n) {
              var i, v = crypto.randomBytes(n);
              for (i = 0; i < n; i++) x[i] = v[i];
              cleanup(v);
            });
          }
        }
      })();
    })(typeof module2 !== "undefined" && module2.exports ? module2.exports : self.nacl = self.nacl || {});
  }
});

// src/main.ts
var main_exports = {};
__export(main_exports, {
  default: () => CalderaPlugin
});
module.exports = __toCommonJS(main_exports);
var import_obsidian4 = require("obsidian");

// ../core/dist/index.js
var import_tweetnacl = __toESM(require_nacl_fast(), 1);

// ../core/dist/agent-prompt.js
function agentPrompt(o = {}) {
  const hub = (o.hubUrl || "https://caldera.social").replace(/\/$/, "");
  const vault = o.vaultPath || "<ABSOLUTE PATH TO MY OBSIDIAN VAULT>";
  const activity = o.activityFile || "Caldera/activity.json";
  const zip = o.zipUrl || hub + "/download/caldera-latest.zip";
  const topics = o.publicTopics?.length ? o.publicTopics.map((t) => "#" + t).join(", ") : "the tags I allow-listed in Settings -> Caldera -> Public topics";
  const page = o.handle ? `${hub}/@${o.handle}/` : `${hub}/@<my handle>/`;
  const install = o.installed ? `## 1. Install
Caldera is already installed and enabled in this vault. Skip to step 2.
` : `## 1. Install the plugin
1. Download ${zip} and unzip it into "${vault}/.obsidian/plugins/caldera/" so that folder contains main.js, manifest.json and styles.css.
2. Add "caldera" to the JSON array in "${vault}/.obsidian/community-plugins.json" (create the file as ["caldera"] if it does not exist). Do not remove other entries.
3. Tell me to restart Obsidian. If Obsidian asks, I turn off Restricted mode (Settings -> Community plugins -> Turn on community plugins) and make sure Caldera is switched on. Caldera then opens a Welcome window where I type my name and pick a handle; it creates my identity on this device, publishes my profile and opens it in my browser. Do NOT create the identity, read the plugin's data.json, or handle my keys yourself - that file holds my private key. Wait until I tell you my profile is live, then continue with step 2.
`;
  return `You are helping me run Caldera, the social layer for my Obsidian vault (${hub}). Caldera builds a public profile page from my vault. Follow these instructions exactly.

Vault: ${vault}${o.vaultPath ? "" : "\n(If I did not fill this in, find my vault yourself: it is the folder that contains a .obsidian folder. If there is more than one, ask me which.)"}
My public page: ${page}

${install}
## 2. Daily routine (run once a day, in the morning, for YESTERDAY's date; I will schedule you)
A. Journal entry. Open (or create) yesterday's daily note, named YYYY-MM-DD.md, wherever my daily notes live. Add these frontmatter properties, keeping everything already in the note:
   caldera_headline: one sentence, the shape of the day
   caldera_focus: 2-4 short items, what I worked on
   caldera_wins: 1-3 short items, what got done
   caldera_themes: 1-3 single words
   Write them from my notes, calendar, sent email, commits and AI sessions for that day - whatever you can access.

B. Activity counts. Update "${vault}/${activity}" (create it if missing). Format:
   { "days": [ { "date": "YYYY-MM-DD", "meetings": 0, "emails": 0, "prompts": 0, "commits": 0, "docs": 0 } ] }
   One object per date: replace that date's object if it exists, keep the last 60 days, and only include counts you can actually measure (omit the rest - never guess). meetings = calendar events attended, emails = emails I sent, prompts = AI prompts I sent, commits = git commits I authored, docs = documents/attachments I produced or filed. Notes are counted by the plugin itself.

C. Publish. If Caldera auto-publish is on (Settings -> Caldera -> Auto-publish every N hours), you are done. Otherwise ask me to run "Caldera: Publish my profile" from the command palette.

## 3. Privacy rules (these override everything above)
Everything you write in the caldera_* fields and in ${activity} is PUBLIC on the internet. So:
- No names of people, companies, clients, investors, deals, or products that are not already public on my page.
- No money amounts, prices, valuations, metrics, health, legal, family, location or travel details.
- No email addresses, phone numbers, URLs to private docs, or anything copied from email bodies.
- Describe work by its public theme instead ("closed out a design review", "shipped a release"), and only use topics among ${topics}.
- If you are unsure whether something is private, leave it out. An empty field is fine.
- Never write to any other part of the vault, never change notes' privacy markings (caldera: public / friends), never touch .obsidian/plugins/caldera/data.json.

## 4. Check your work
After each run, tell me in two lines what you wrote for that day, and anything you skipped because it looked private.

## 5. When I ask you to change my page
My name, headline, photo, banner, links, properties, topics, which sections show and whether I'm listed in the directory all live in the frontmatter of "${vault}/Caldera/profile.md". Edit that file (keep its format; the same privacy rules apply) and the page republishes itself within about a minute. Guide: ${hub}/guide.html`;
}
function richerPrompt(o = {}) {
  const hub = (o.hubUrl || "https://caldera.social").replace(/\/$/, "");
  const vault = o.vaultPath || "<ABSOLUTE PATH TO MY OBSIDIAN VAULT>";
  const activity = o.activityFile || "Caldera/activity.json";
  return `Help me make my Caldera profile richer. Caldera (${hub}) builds a public profile page from my Obsidian vault.

Vault: ${vault}${o.vaultPath ? "" : "\n(If I did not fill this in, find my vault yourself: it is the folder that contains a .obsidian folder. If there is more than one, ask me which.)"}

Work through these one at a time. Anything that would become PUBLIC needs my explicit yes first: show me exactly what you propose, wait for my answer, then make only the approved changes.

1. Public notes. Find 3-8 notes that would be good to show publicly: evergreen essays, how-tos, reading notes, overviews of work that is already public. Skip anything about people, clients, deals, money, health, family or unannounced work. List them with one line each on why. After I approve, add "caldera: public" to the frontmatter of the approved notes only. The page shows each note's title and first paragraph, so check that first paragraph too.

2. Notes friends can receive. Suggest notes I might want to share with friends as encrypted cards (frameworks, checklists, templates). After I approve, add "caldera: friends" to their frontmatter. These are not public; only friends I pick receive them.

3. Public topics. List my 10 most-used tags that are safe to show publicly (no client, company or people tags), with a short label for each. I will add them myself in Settings -> Caldera -> Public topics. Do not edit plugin settings.

4. Activity sources. Set up a daily scheduled job (cron, launchd, Task Scheduler, or your own scheduler) that writes COUNTS ONLY for yesterday into "${vault}/${activity}" in this format, replacing that date's entry and keeping 60 days:
   { "days": [ { "date": "YYYY-MM-DD", "meetings": 0, "emails": 0, "prompts": 0, "commits": 0, "docs": 0 } ] }
   Use the sources I actually have: calendar events attended, emails I sent, AI prompts I sent, git commits I authored, documents I produced. Only numbers - never titles, subjects, names or contents. Tell me which sources you connected and which you could not. If a daily journal routine already writes this file, extend it instead of adding a second writer.

5. Backfill the journal. For each of the last 14 days that has activity, add caldera_headline, caldera_focus, caldera_wins and caldera_themes to that day's daily note (YYYY-MM-DD.md), following the privacy rules below. Show me the 14 entries before writing them.

6. Asks and offers. Draft 2 asks ("I could use help with...") and 2 offers ("I can help with...") that fit what I work on. I will post the ones I like with the commands "Caldera: Post an ask" and "Caldera: Post an offer".

7. Finish. Tell me to run "Caldera: Preview my public profile", check it, then "Caldera: Publish my profile".

Privacy rules (these override everything above):
- Never put names of people, companies, clients, investors, deals or unannounced products into anything public.
- No money amounts, prices, valuations, metrics, health, legal, family, location or travel details.
- No email addresses, phone numbers, or links to private documents.
- If you are unsure whether something is private, leave it out.
- Never read or edit .obsidian/plugins/caldera/data.json - it holds my private key.
- Never remove or change an existing "caldera:" marking without asking me.`;
}
function editPrompt(o = {}) {
  const hub = (o.hubUrl || "https://caldera.social").replace(/\/$/, "");
  const vault = o.vaultPath || "<ABSOLUTE PATH TO MY OBSIDIAN VAULT>";
  return `Help me change my Caldera profile (${hub}/@${o.handle || "<my handle>"}/). Caldera builds that public page from my Obsidian vault.

Vault: ${vault}${o.vaultPath ? "" : "\n(If I did not fill this in, find my vault yourself: it is the folder that contains a .obsidian folder. If there is more than one, ask me which.)"}

Where things live:
- Name, headline, photo, banner, links, properties, topics, which sections show, and directory listing: the frontmatter of "Caldera/profile.md". Keep its format. Photo and banner are paths to images inside the vault.
- A note on my page: add "caldera: public" to that note's frontmatter (title and first paragraph are shown). Remove it to take the note down.
- My daily journal: caldera_headline / caldera_focus / caldera_wins / caldera_themes in daily notes named YYYY-MM-DD.md.
- Activity counts: "Caldera/activity.json".
The page republishes automatically about a minute after Caldera/profile.md changes. For anything else, tell me to run "Caldera: Publish my profile".

Rules:
- Show me the exact change before you make it, and only make what I approve.
- Everything on the page is public: no private names, clients, deals, money, health, family, location, emails or phone numbers.
- Never read or edit .obsidian/plugins/caldera/data.json - it holds my private key. My handle can only be changed in Settings -> Caldera.

What I want to change: <DESCRIBE THE CHANGE>`;
}

// ../core/dist/index.js
var PROTOCOL_VERSION = 1;
var B58 = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz";
function b58encode(bytes) {
  let n = 0n;
  for (const b of bytes)
    n = (n << 8n) + BigInt(b);
  let out = "";
  while (n > 0n) {
    out = B58[Number(n % 58n)] + out;
    n /= 58n;
  }
  for (const b of bytes) {
    if (b === 0)
      out = "1" + out;
    else
      break;
  }
  return out;
}
function b58decode(s) {
  let n = 0n;
  for (const c of s) {
    const i = B58.indexOf(c);
    if (i < 0)
      throw new Error("bad base58");
    n = n * 58n + BigInt(i);
  }
  const bytes = [];
  while (n > 0n) {
    bytes.unshift(Number(n & 255n));
    n >>= 8n;
  }
  for (const c of s) {
    if (c === "1")
      bytes.unshift(0);
    else
      break;
  }
  return new Uint8Array(bytes);
}
var b64 = {
  enc(u) {
    let s = "";
    for (const b of u)
      s += String.fromCharCode(b);
    return btoa(s);
  },
  dec(s) {
    const bin = atob(s);
    const u = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++)
      u[i] = bin.charCodeAt(i);
    return u;
  }
};
var utf8 = (s) => new TextEncoder().encode(s);
var fromUtf8 = (u) => new TextDecoder().decode(u);
function canonical(value) {
  if (value === null || typeof value !== "object")
    return JSON.stringify(value);
  if (Array.isArray(value))
    return "[" + value.map(canonical).join(",") + "]";
  const obj = value;
  return "{" + Object.keys(obj).filter((k) => obj[k] !== void 0).sort().map((k) => JSON.stringify(k) + ":" + canonical(obj[k])).join(",") + "}";
}
function newIdentity() {
  const sign2 = import_tweetnacl.default.sign.keyPair();
  const box = import_tweetnacl.default.box.keyPair();
  return {
    id: idFromPublicKey(sign2.publicKey),
    signPublic: b64.enc(sign2.publicKey),
    signSecret: b64.enc(sign2.secretKey),
    boxPublic: b64.enc(box.publicKey),
    boxSecret: b64.enc(box.secretKey)
  };
}
function idFromPublicKey(pk) {
  return "cal:" + b58encode(pk);
}
function publicKeyFromId(id) {
  if (!id.startsWith("cal:"))
    throw new Error("not a caldera id");
  const pk = b58decode(id.slice(4));
  if (pk.length !== 32)
    throw new Error("bad id length");
  return pk;
}
function signingBytes(e) {
  return utf8(canonical({ v: e.v, type: e.type, from: e.from, ts: e.ts, body: e.body }));
}
function sign(identity, type, body, ts = (/* @__PURE__ */ new Date()).toISOString()) {
  const unsigned = { v: PROTOCOL_VERSION, type, from: identity.id, ts, body };
  const sig = import_tweetnacl.default.sign.detached(signingBytes(unsigned), b64.dec(identity.signSecret));
  return { ...unsigned, sig: b64.enc(sig) };
}
function verify(e) {
  try {
    if (!e || e.v !== PROTOCOL_VERSION || typeof e.sig !== "string")
      return false;
    return import_tweetnacl.default.sign.detached.verify(signingBytes(e), b64.dec(e.sig), publicKeyFromId(e.from));
  } catch {
    return false;
  }
}
function envelopeHash(e) {
  return b64.enc(import_tweetnacl.default.hash(utf8(canonical(e)))).slice(0, 43);
}
function seal(plaintext, recipientBoxPublic, sender) {
  const nonce = import_tweetnacl.default.randomBytes(import_tweetnacl.default.box.nonceLength);
  const box = import_tweetnacl.default.box(utf8(plaintext), nonce, b64.dec(recipientBoxPublic), b64.dec(sender.boxSecret));
  return { nonce: b64.enc(nonce), box: b64.enc(box) };
}
function open(sealed, senderBoxPublic, recipient) {
  const out = import_tweetnacl.default.box.open(b64.dec(sealed.box), b64.dec(sealed.nonce), b64.dec(senderBoxPublic), b64.dec(recipient.boxSecret));
  return out ? fromUtf8(out) : null;
}
var ACTIVITY_WEIGHTS = { meetings: 6, emails: 2, prompts: 1, commits: 0.5, notes: 0.25, docs: 1 };
var ACTIVITY_CAPS = { notes: 60, docs: 40, commits: 200 };
function activityScore(c) {
  let s = 0;
  for (const [k, w] of Object.entries(ACTIVITY_WEIGHTS)) {
    s += w * Math.min(c[k] ?? 0, ACTIVITY_CAPS[k] ?? Infinity);
  }
  return Math.round(s);
}
function newId(prefix) {
  return prefix + "_" + b58encode(import_tweetnacl.default.randomBytes(12));
}

// src/settings.ts
var import_obsidian = require("obsidian");
var DEFAULT_SETTINGS = {
  hubUrl: "https://caldera.social",
  identity: null,
  handle: "",
  name: "",
  headline: "",
  theme: "dark",
  avatarPath: "",
  bannerPath: "",
  links: [],
  properties: [],
  sections: { journal: true, scoreboard: true, properties: true, numbers: true, topics: true, notes: true, asks: true, social: true, links: true, sidebar: true, rail: true },
  publicTopics: [["ai", "AI"], ["design", "Design"], ["startups", "Startups"], ["investing", "Investing"], ["writing", "Writing"]],
  activityFile: "Caldera/activity.json",
  historyDays: 45,
  inboxFolder: "Caldera/Inbox",
  lastInboxSync: "1970-01-01T00:00:00.000Z",
  asks: [],
  offers: [],
  autoPublishHours: 6,
  welcomed: false,
  listed: true,
  lastSeenRelease: "",
  tree: [],
  graph: [],
  backlinks: [],
  summary: "",
  now: [],
  timeline: [],
  projects: [],
  knows: []
};
var SECTION_LABELS = {
  journal: "Daily journal (flip through days)",
  scoreboard: "Scoreboard (streak, rank, 30-day bars)",
  properties: "Properties",
  numbers: "Vault numbers (notes, words, links, active days)",
  topics: "Topics (allow-listed tags only)",
  notes: "Notes marked caldera: public",
  asks: "Help exchange (asks and offers)",
  social: "Friends, gravity and credits",
  links: "Links elsewhere"
};
var CalderaSettingTab = class extends import_obsidian.PluginSettingTab {
  constructor(app, plugin) {
    super(app, plugin);
    this.plugin = plugin;
  }
  display() {
    const { containerEl } = this;
    const s = this.plugin.settings;
    containerEl.empty();
    containerEl.createEl("h2", { text: "Caldera" });
    containerEl.createEl("p", { text: "Your vault stays private. Only the sections you switch on below, notes you mark caldera: public, and counts are published. Use 'Preview profile' before publishing.", cls: "setting-item-description" });
    containerEl.createEl("h3", { text: "Identity" });
    new import_obsidian.Setting(containerEl).setName("Your Caldera ID").setDesc(s.identity ? s.identity.id : "Not created yet").addButton((b) => b.setButtonText(s.identity ? "Copy ID" : "Create identity").onClick(async () => {
      if (!s.identity) {
        await this.plugin.ensureIdentity();
        this.display();
      } else {
        await navigator.clipboard.writeText(s.identity.id);
        new import_obsidian.Notice("ID copied");
      }
    })).addButton((b) => b.setButtonText("Export recovery key").setDisabled(!s.identity).onClick(async () => {
      await navigator.clipboard.writeText(btoa(JSON.stringify(s.identity)));
      new import_obsidian.Notice("Recovery key copied. Store it somewhere safe; anyone with it can act as you.");
    }));
    this.text("Handle", "Your address on the hub: hub/@handle", "handle", (v) => v.toLowerCase().replace(/[^a-z0-9-]/g, ""));
    this.text("Hub", "Where your profile is hosted and friends connect. Self-hosters can point this at their own hub.", "hubUrl");
    new import_obsidian.Setting(containerEl).setName("List me in the directory").setDesc("Show your profile card on the public People page. Off: your page still works for anyone with the link, but isn't browsable.").addToggle((t) => t.setValue(s.listed !== false).onChange(async (v) => {
      s.listed = v;
      await this.plugin.saveSettings();
    }));
    containerEl.createEl("h3", { text: "Profile" });
    new import_obsidian.Setting(containerEl).setName("Edit your page as a note").setDesc("Name, headline, photo, links, topics and sections also live in Caldera/profile.md. Edit it (or ask your AI agent to) and the page republishes itself. Values there win over the fields below.").addButton((b) => b.setButtonText("Open profile file").onClick(() => this.plugin.openProfileFile()));
    this.text("Name", "", "name");
    this.text("Headline", "One line under your name", "headline");
    this.text("Avatar image", "Path in your vault, e.g. Attachments/me.jpg", "avatarPath");
    this.text("Banner image", "Path in your vault", "bannerPath");
    new import_obsidian.Setting(containerEl).setName("Theme").addDropdown((d) => d.addOptions({ dark: "Dark", light: "Light" }).setValue(s.theme).onChange(async (v) => {
      s.theme = v;
      await this.plugin.saveSettings();
    }));
    this.pairs("Links", "One per line: Label | https://url", "links");
    this.pairs("Properties", "One per line: key | value (shown as a properties block)", "properties");
    containerEl.createEl("h3", { text: "What is public" });
    for (const [k, label] of Object.entries(SECTION_LABELS)) {
      new import_obsidian.Setting(containerEl).setName(label).addToggle((t) => t.setValue(!!s.sections[k]).onChange(async (v) => {
        s.sections[k] = v;
        await this.plugin.saveSettings();
      }));
    }
    this.pairs("Public topics", "Only these tags are counted. One per line: tag | Label", "publicTopics");
    this.text("Activity file", "Optional JSON of daily counts from outside tools (calendar, email, git)", "activityFile");
    containerEl.createEl("h3", { text: "Publishing" });
    new import_obsidian.Setting(containerEl).setName("Auto-publish every N hours").setDesc("0 = only when you click Publish").addText((t) => t.setValue(String(s.autoPublishHours)).onChange(async (v) => {
      s.autoPublishHours = Math.max(0, Number(v) || 0);
      await this.plugin.saveSettings();
      this.plugin.scheduleAutoPublish();
    }));
  }
  text(name, desc, key, clean = (v) => v) {
    new import_obsidian.Setting(this.containerEl).setName(name).setDesc(desc).addText((t) => t.setValue(String(this.plugin.settings[key] ?? "")).onChange(async (v) => {
      this.plugin.settings[key] = clean(v.trim());
      await this.plugin.saveSettings();
    }));
  }
  pairs(name, desc, key) {
    new import_obsidian.Setting(this.containerEl).setName(name).setDesc(desc).addTextArea((t) => {
      t.setValue(this.plugin.settings[key].map((p) => p.join(" | ")).join("\n"));
      t.inputEl.rows = 4;
      t.onChange(async (v) => {
        this.plugin.settings[key] = v.split("\n").map((l) => l.split("|").map((x) => x.trim())).filter((p) => p[0] && p[1]).map((p) => [p[0], p.slice(1).join("|")]);
        await this.plugin.saveSettings();
      });
    });
  }
};

// src/collect.ts
var import_obsidian2 = require("obsidian");
var DAY = 864e5;
var fmtN = (n) => n.toLocaleString("en-US");
var iso = (t) => {
  const d = new Date(t);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};
async function collectProfile(app, s, social) {
  const md = app.vault.getMarkdownFiles();
  let words = 0, links = 0;
  const created = /* @__PURE__ */ new Map(), changed = /* @__PURE__ */ new Map();
  const tagCounts = /* @__PURE__ */ new Map();
  const allow = new Map(s.publicTopics.map(([tag, label]) => [tag.toLowerCase().replace(/^#/, ""), label]));
  const publicNotes = [];
  const journal = /* @__PURE__ */ new Map();
  for (const f of md) {
    created.set(iso(f.stat.ctime), (created.get(iso(f.stat.ctime)) || 0) + 1);
    changed.set(iso(f.stat.mtime), (changed.get(iso(f.stat.mtime)) || 0) + 1);
    const cache = app.metadataCache.getFileCache(f);
    links += (cache?.links?.length || 0) + (cache?.embeds?.length || 0) + (cache?.frontmatterLinks?.length || 0);
    words += Math.round(f.stat.size / 6);
    for (const t of cache ? (0, import_obsidian2.getAllTags)(cache) || [] : []) {
      const k = t.replace(/^#/, "").toLowerCase();
      if (allow.has(k)) tagCounts.set(allow.get(k), (tagCounts.get(allow.get(k)) || 0) + 1);
    }
    const fm = cache?.frontmatter || {};
    if (String(fm.caldera || "").toLowerCase() === "public") {
      const text = await app.vault.cachedRead(f);
      const body = text.replace(/^---[\s\S]*?---\s*/, "");
      const para = body.split(/\n\s*\n/).map((x) => x.replace(/^#+\s.*$/gm, "").trim()).find((x) => x.length > 20) || "";
      publicNotes.push({ title: f.basename, excerpt: para.replace(/\[\[([^\]|]+)(\|[^\]]+)?\]\]/g, "$1").slice(0, 280), updated: new Date(f.stat.mtime).toISOString() });
    }
    const dm = f.basename.match(/^(\d{4}-\d{2}-\d{2})$/);
    if (dm && (fm.caldera_headline || fm.caldera_focus || fm.caldera_wins)) {
      journal.set(dm[1], { headline: fm.caldera_headline, focus: asList(fm.caldera_focus), wins: asList(fm.caldera_wins), themes: asList(fm.caldera_themes) });
    }
  }
  const external = /* @__PURE__ */ new Map();
  let extra = {};
  const actFile = app.vault.getAbstractFileByPath(s.activityFile);
  if (actFile instanceof import_obsidian2.TFile) {
    try {
      extra = JSON.parse(await app.vault.cachedRead(actFile)) || {};
      for (const d of extra.days || []) external.set(d.date, d);
    } catch {
    }
  }
  const today = Date.now();
  const daily = [];
  for (let i = s.historyDays - 1; i >= 0; i--) {
    const date = iso(today - i * DAY);
    const ext = external.get(date) || {};
    const j = journal.get(date) || {};
    daily.push({
      date,
      counts: { notes: Math.max(created.get(date) || 0, changed.get(date) || 0), meetings: ext.meetings, emails: ext.emails, prompts: ext.prompts, commits: ext.commits, docs: ext.docs },
      tokens: Number(ext.tokens) || void 0,
      headline: j.headline || ext.headline,
      focus: j.focus?.length ? j.focus : asList(ext.focus),
      wins: j.wins?.length ? j.wins : asList(ext.wins),
      themes: j.themes?.length ? j.themes : asList(ext.themes)
    });
  }
  let activeDays = 0;
  for (let i = 0; i < 182; i++) {
    const d = iso(today - i * DAY);
    if ((created.get(d) || 0) + (changed.get(d) || 0) > 0) activeDays++;
  }
  const files = {};
  const img = async (vaultPath, name) => {
    const f = vaultPath && app.vault.getAbstractFileByPath(vaultPath);
    if (f instanceof import_obsidian2.TFile) {
      const out = `img/${name}.${f.extension}`;
      files[out] = await app.vault.readBinary(f);
      return out;
    }
    return void 0;
  };
  const inbound = /* @__PURE__ */ new Map();
  const bump = (k) => inbound.set(k, (inbound.get(k) || 0) + 1);
  for (const targets of Object.values(app.metadataCache.resolvedLinks)) for (const t of Object.keys(targets)) bump(t.split("/").pop().replace(/\.md$/i, "").toLowerCase());
  for (const targets of Object.values(app.metadataCache.unresolvedLinks)) for (const t of Object.keys(targets)) bump(t.split("|")[0].split("/").pop().replace(/\.md$/i, "").toLowerCase());
  const linkCount = (name) => inbound.get(name.toLowerCase()) || 0;
  const topTopics = [...tagCounts.entries()].sort((a, b) => b[1] - a[1]);
  const notesSorted = publicNotes.sort((a, b) => b.updated.localeCompare(a.updated)).slice(0, 12);
  const tree = [{ name: "People", child: false }, { name: s.name || "Me", child: true, current: true }];
  const groups = s.tree?.length ? s.tree.map(([g, items]) => [g, items.split(",").map((x) => x.trim()).filter(Boolean)]) : [["Topics", topTopics.slice(0, 5).map((t) => t[0])], ["Notes", notesSorted.slice(0, 5).map((n) => n.title)]];
  for (const [g, items] of groups) {
    if (!items.length && !s.tree?.length) continue;
    tree.push({ name: g, child: false });
    for (const it of items) tree.push({ name: it, child: true });
  }
  const graph = (s.graph?.length ? s.graph.map((n) => ({ t: n, n: linkCount(n) })) : topTopics.slice(0, 12).map(([t, n]) => ({ t, n }))).slice(0, 16);
  const backlinks = s.backlinks?.length ? s.backlinks : notesSorted.slice(0, 6).map((n) => [n.title, n.excerpt.slice(0, 70)]);
  const DAYMS = 864e5, todayD = /* @__PURE__ */ new Date();
  todayD.setHours(12, 0, 0, 0);
  const startD = new Date(todayD.getTime() - ((todayD.getDay() + 6) % 7 + 7 * 25) * DAYMS);
  const heat = [];
  for (let t = startD.getTime(); t <= todayD.getTime(); t += DAYMS) {
    const d = iso(t), e = external.get(d) || {};
    heat.push({ date: d, n: (created.get(d) || 0) + (changed.get(d) || 0) + (Number(e.docs) || 0) });
  }
  const createdDays = [...created.keys()].sort();
  const growth = [];
  if (createdDays.length) {
    const first = /* @__PURE__ */ new Date(createdDays[0] + "T12:00:00");
    first.setDate(first.getDate() - (first.getDay() + 6) % 7);
    let total = 0;
    for (let w = first.getTime(); w <= todayD.getTime(); w += 7 * DAYMS) {
      for (let k = 0; k < 7; k++) total += created.get(iso(w + k * DAYMS)) || 0;
      growth.push({ week: iso(w), total });
    }
  }
  const knows = s.knows?.length ? s.knows.map(([label, folder]) => {
    const pre = folder.replace(/^\/+|\/+$/g, "") + "/";
    return [label, md.filter((f) => f.path.startsWith(pre)).length];
  }) : Array.isArray(extra.knows) ? extra.knows.filter((k) => Array.isArray(k) && typeof k[1] === "number").map((k) => [String(k[0]), k[1]]) : [];
  const pc = extra.projects && typeof extra.projects === "object" ? extra.projects : {};
  const projects = (s.projects || []).map(([name, rest]) => {
    const [status = "", url = ""] = rest.split("|").map((x) => x.trim());
    return { name, status, url, commits: Number(pc[name]) || void 0 };
  });
  const data = {
    name: s.name || "Untitled",
    handle: s.handle || void 0,
    headline: s.headline,
    theme: s.theme,
    avatar: await img(s.avatarPath, "avatar"),
    banner: await img(s.bannerPath, "banner"),
    links: s.links.filter((l) => l[0] && l[1]),
    properties: s.properties.filter((p) => p[0] && p[1]),
    sections: s.sections,
    stats: { notes: md.length, words, links, activeDays },
    topics: [...tagCounts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 18),
    daily,
    publicNotes: notesSorted,
    summary: s.summary || void 0,
    now: s.now,
    timeline: s.timeline,
    projects,
    heat,
    growth,
    knows,
    inbox: extra.inbox && Array.isArray(extra.inbox.kinds) ? extra.inbox : void 0,
    code: extra.code && typeof extra.code.commits === "number" ? extra.code : void 0,
    ai: extra.ai && typeof extra.ai.total === "number" && Array.isArray(extra.ai.models) ? extra.ai : void 0,
    extraNumbers: Array.isArray(extra.numbers) ? extra.numbers.filter((x) => Array.isArray(x)).map((x) => [String(x[0]), String(x[1])]) : void 0,
    tree,
    graph,
    graphLabel: s.graph?.length ? "Local graph / sized by linked notes" : "Topics / sized by notes",
    backlinks,
    backlinkLabel: s.backlinks?.length ? `Backlinks / ${fmtN(linkCount(s.name || ""))} notes link here` : "Public notes",
    asks: s.asks,
    offers: s.offers,
    social,
    updated: (/* @__PURE__ */ new Date()).toISOString()
  };
  return { data, files };
}
function asList(v) {
  if (Array.isArray(v)) return v.map(String).filter(Boolean).slice(0, 3);
  if (typeof v === "string" && v.trim()) return [v.trim()];
  return [];
}

// src/assets/theme.css
var theme_default = `/* ============================================================================
   LIVING PROFILE - DESIGN TOKENS
   This is the ONLY file you need to edit to restyle the whole page.
   Every color, font, size, radius and spacing used anywhere comes from here.
   profile.css uses these variables only; it never hard-codes a color.

   Quick recipes:
   - Switch to the light theme:  <html data-theme="light"> in index template,
     or set "theme": "light" in config/profile.json.
   - New accent color:           change --accent (and --accent-soft).
   - Different fonts:            change --font-body / --font-display / --font-mono
                                 (and the Google Fonts link in the template).
   - Tighter / looser layout:    change --space-unit.
   ========================================================================== */

:root {
  /* --- Typography ------------------------------------------------------- */
  --font-body: 'IBM Plex Sans', 'Helvetica Neue', Arial, sans-serif;
  --font-display: 'Source Serif 4', Georgia, serif;
  --font-mono: 'IBM Plex Mono', ui-monospace, Menlo, monospace;

  --text-xs: 11.5px;
  --text-sm: 13.5px;
  --text-md: 15px;
  --text-lg: 18px;
  --text-h2: 26px;
  --text-h1: clamp(34px, 5vw, 46px);
  --leading: 1.65;

  /* --- Spacing & shape -------------------------------------------------- */
  --space-unit: 8px;                       /* everything scales off this */
  --space-1: calc(var(--space-unit) * 0.5);
  --space-2: var(--space-unit);
  --space-3: calc(var(--space-unit) * 1.5);
  --space-4: calc(var(--space-unit) * 2);
  --space-6: calc(var(--space-unit) * 3);
  --space-8: calc(var(--space-unit) * 4);
  --radius-sm: 6px;
  --radius-md: 8px;
  --radius-lg: 14px;
  --radius-round: 999px;

  /* --- Layout ----------------------------------------------------------- */
  --sidebar-width: 250px;
  --rail-width: 300px;
  --content-width: 760px;
  --banner-height: 260px;
  --avatar-size: 112px;
  --banner-focus: 62% 14%;   /* which part of the banner photo stays in view (x y) */

  /* --- Color: dark theme (default) -------------------------------------- */
  --bg: #1C1C1F;           /* page */
  --bg-sunken: #17171A;    /* sidebars */
  --bg-raised: #232327;    /* cards, buttons */
  --bg-tab: #141416;       /* top tab bar */
  --line: #2A2A2E;         /* hairlines */
  --line-strong: #3A3A40;
  --text: #DADADF;
  --text-strong: #F2F2F5;
  --text-muted: #8A8A93;
  --accent: #8B6CF6;       /* links, highlights, graph center */
  --accent-text: #B39DFA;  /* link text on dark */
  --accent-soft: rgba(139, 108, 246, .10);
  --accent-2: #4FB89A;     /* secondary accent (help exchange, gravity) */
  --on-accent: #FFFFFF;
  --chart-bar: var(--accent);
  --chart-bar-quiet: rgba(139, 108, 246, .55);
  --graph-node: #6E6E78;
  --graph-node-hot: var(--accent-text);
  --graph-edge: var(--line-strong);
  /* activity heatmap, empty -> busiest */
  --heat-0: #232327;
  --heat-1: #3A2F66;
  --heat-2: #5B47B0;
  --heat-3: #8B6CF6;
  --heat-4: #C7B8FF;
  --chart-alt: var(--accent-2);  /* second chart color */
}

/* --- Color: light theme ------------------------------------------------- */
:root[data-theme="light"] {
  --bg: #FFFFFF;
  --bg-sunken: #F6F6F7;
  --bg-raised: #F0F0F2;
  --bg-tab: #EDEDF0;
  --line: #E4E4E7;
  --line-strong: #D0D0D6;
  --text: #2B2B30;
  --text-strong: #0D0D10;
  --text-muted: #6E6E78;
  --accent: #6D4AE8;
  --accent-text: #5A38D6;
  --accent-soft: rgba(109, 74, 232, .08);
  --accent-2: #138A6A;
  --graph-node: #A8A8B3;
  --heat-0: #EDEDF0;
  --heat-1: #D9D0FB;
  --heat-2: #B3A1F6;
  --heat-3: #8B6CF6;
  --heat-4: #5A38D6;
}
`;

// src/profile.css.ts
var PROFILE_CSS = '/* ============================================================================\n   LIVING PROFILE - COMPONENTS\n   Layout and components only. No raw colors, fonts or sizes here:\n   everything comes from theme.css. To restyle, edit theme.css.\n   ========================================================================== */\n\n* { box-sizing: border-box; }\nhtml, body { margin: 0; }\nbody {\n  background: var(--bg);\n  color: var(--text);\n  font-family: var(--font-body);\n  font-size: var(--text-md);\n  line-height: var(--leading);\n  -webkit-font-smoothing: antialiased;\n}\na { color: var(--accent-text); text-decoration: none; }\na:hover { text-decoration: underline; }\n.mono { font-family: var(--font-mono); }\n.muted { color: var(--text-muted); }\n\n/* --- Top tab bar ------------------------------------------------------- */\n.tabs {\n  display: flex; align-items: center; gap: var(--space-1);\n  background: var(--bg-tab); border-bottom: 1px solid var(--line);\n  padding: 0 var(--space-3); overflow-x: auto;\n}\n.tab { padding: 10px 14px; font-size: var(--text-sm); color: var(--text-muted); white-space: nowrap; }\n.tab.is-active {\n  color: var(--text); background: var(--bg);\n  border: 1px solid var(--line); border-bottom: 0;\n  border-radius: var(--radius-md) var(--radius-md) 0 0;\n}\n.tabs .spacer { flex: 1; }\n.sync { font-family: var(--font-mono); font-size: var(--text-xs); color: var(--text-muted); white-space: nowrap; padding-right: var(--space-2); }\n.sync .dot { display: inline-block; width: 7px; height: 7px; border-radius: 50%; background: var(--accent-2); margin-right: 6px; animation: pulse 2.4s ease-in-out infinite; }\n\n/* --- Three-column shell ------------------------------------------------ */\n.shell { display: flex; flex-wrap: wrap; align-items: stretch; }\n.sidebar {\n  flex: 0 1 var(--sidebar-width); min-width: 200px;\n  background: var(--bg-sunken); border-right: 1px solid var(--line);\n  padding: var(--space-3) var(--space-2); font-size: var(--text-sm);\n}\n.note { flex: 999 1 560px; min-width: 0; padding-bottom: var(--space-8); }\n.rail {\n  flex: 0 1 var(--rail-width); min-width: 240px;\n  background: var(--bg-sunken); border-left: 1px solid var(--line);\n  padding: var(--space-3); display: flex; flex-direction: column; gap: var(--space-4);\n}\n@media (max-width: 900px) {\n  .sidebar { display: none; }\n  .rail { border-left: 0; border-top: 1px solid var(--line); flex-basis: 100%; }\n}\n\n/* --- File tree --------------------------------------------------------- */\n.label { font-family: var(--font-mono); font-size: var(--text-xs); color: var(--text-muted); letter-spacing: .04em; text-transform: uppercase; }\n.tree .label { padding: 0 var(--space-2) var(--space-2); display: block; }\n.tree-row { display: flex; justify-content: space-between; gap: var(--space-2); padding: 4px var(--space-2); border-radius: var(--radius-sm); color: var(--text); }\n.tree-row.child { padding-left: calc(var(--space-2) + 16px); color: var(--text-muted); }\n.tree-row.is-current { background: var(--bg-raised); color: var(--text-strong); }\n.tree-row .count { font-family: var(--font-mono); font-size: var(--text-xs); color: var(--graph-node); }\n\n/* --- Banner & title ---------------------------------------------------- */\n.banner { position: relative; height: var(--banner-height); }   /* no overflow:hidden, so the avatar can hang below */\n.banner::after { z-index: 1; }\n.banner img.cover { width: 100%; height: 100%; object-fit: cover; object-position: var(--banner-focus); opacity: .92; display: block; }\n.banner::after { content: ""; position: absolute; inset: 0; background: linear-gradient(180deg, transparent 40%, var(--bg) 100%); }\n.banner img.avatar {\n  position: absolute; left: 48px; bottom: calc(var(--avatar-size) * -0.32); z-index: 2;\n  width: var(--avatar-size); height: var(--avatar-size); border-radius: 50%;\n  object-fit: cover; object-position: center 25%; border: 4px solid var(--bg);\n}\n.page { max-width: var(--content-width); margin: 0 auto; padding: calc(var(--space-8) + var(--space-4)) var(--space-8) 0; }\n.crumb { font-family: var(--font-mono); font-size: 12px; color: var(--text-muted); }\nh1.title { margin: 6px 0 var(--space-4); font-family: var(--font-display); font-weight: 600; font-size: var(--text-h1); color: var(--text-strong); line-height: 1.1; }\nh1.title .caret { color: var(--accent); animation: blink 1s step-end infinite; }\nh2 { font-family: var(--font-display); font-weight: 600; font-size: var(--text-h2); color: var(--text-strong); margin: var(--space-8) 0 var(--space-2); }\n\n/* --- Properties -------------------------------------------------------- */\n.props {\n  display: grid; grid-template-columns: 150px 1fr; gap: 6px 14px;\n  border-top: 1px solid var(--line); border-bottom: 1px solid var(--line);\n  padding: 10px 0; margin-bottom: var(--space-6); font-size: var(--text-sm);\n}\n.props dt { font-family: var(--font-mono); font-size: 12.5px; color: var(--text-muted); margin: 0; }\n.props dd { margin: 0; }\n@media (max-width: 560px) { .props { grid-template-columns: 1fr; } .props dd { margin-bottom: 6px; } }\n\n/* --- Callout ----------------------------------------------------------- */\n.callout { border-left: 3px solid var(--accent); background: var(--accent-soft); border-radius: 0 var(--radius-md) var(--radius-md) 0; padding: 12px 16px; margin-bottom: var(--space-6); }\n.callout-title { font-weight: 600; color: var(--accent-text); font-size: var(--text-sm); }\n\n/* --- Lists, tables ----------------------------------------------------- */\nul.bullets { margin: 0; padding-left: 20px; }\nul.bullets li { margin: 4px 0; }\n.query { font-family: var(--font-mono); font-size: var(--text-xs); color: var(--text-muted); margin-bottom: 6px; }\n.table-wrap { overflow-x: auto; }\ntable.data { width: 100%; border-collapse: collapse; font-size: 14px; }\ntable.data th { text-align: left; padding: 8px; border-bottom: 1px solid var(--line-strong); color: var(--text-muted); font-weight: 500; }\ntable.data td { padding: 8px; border-bottom: 1px solid var(--line); }\ntable.data .num { text-align: right; font-family: var(--font-mono); }\n\n/* --- Commit chart ------------------------------------------------------ */\n.bars { height: 110px; display: flex; gap: 3px; align-items: flex-end; border-bottom: 1px solid var(--line-strong); }\n.bars span { flex: 1; background: var(--chart-bar); border-radius: 2px 2px 0 0; transform-origin: bottom; animation: rise 1.1s cubic-bezier(.2,.8,.2,1) both; }\n.bars span.quiet { background: var(--chart-bar-quiet); }\n.bars-legend { display: flex; justify-content: space-between; font-family: var(--font-mono); font-size: var(--text-xs); color: var(--text-muted); margin-top: 4px; }\n\n/* --- Timeline ---------------------------------------------------------- */\n.timeline .row { display: grid; grid-template-columns: 70px 1fr; gap: 12px; padding: 5px 0; }\n.timeline .year { font-family: var(--font-mono); font-size: var(--text-sm); color: var(--text-muted); }\n\n/* --- Right rail -------------------------------------------------------- */\n.graph svg { width: 100%; height: 240px; display: block; }\n.graph .edge { stroke: var(--graph-edge); stroke-width: 1; }\n.graph .node { fill: var(--graph-node); }\n.graph .node.hot { fill: var(--graph-node-hot); }\n.graph .center { fill: var(--accent); }\n.graph text { fill: var(--text-muted); font-family: var(--font-body); font-size: 8.5px; }\n.graph .float { animation: float 4s ease-in-out infinite; }\n.backlink { padding: 6px 0; border-bottom: 1px solid var(--line); font-size: var(--text-sm); }\n.backlink .ctx { color: var(--text-muted); font-size: 12px; }\n.pulse-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: var(--space-2); }\n.pulse-cell { background: var(--bg-raised); border-radius: var(--radius-sm); padding: var(--space-2); }\n.pulse-cell .v { font-size: 20px; color: var(--text-strong); }\n.pulse-cell .l { font-size: var(--text-xs); color: var(--text-muted); }\n\n/* --- Help exchange (off by default in config) -------------------------- */\n.hx-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: var(--space-3); }\n.hx-card { background: var(--bg-raised); border: 1px solid var(--line); border-radius: var(--radius-md); padding: var(--space-4); }\n.hx-row { display: flex; justify-content: space-between; gap: var(--space-2); padding: 6px 0; border-bottom: 1px solid var(--line); font-size: var(--text-sm); }\n.hx-row .bounty { color: var(--accent-2); font-family: var(--font-mono); }\n\n\n/* --- Stat strip -------------------------------------------------------- */\n.stat-strip { display: grid; grid-template-columns: repeat(auto-fit, minmax(110px, 1fr)); gap: 1px; background: var(--line); border: 1px solid var(--line); border-radius: var(--radius-md); overflow: hidden; margin-bottom: var(--space-6); }\n.stat { background: var(--bg); padding: var(--space-3) var(--space-2); }\n.stat .v { font-size: 22px; color: var(--text-strong); font-variant-numeric: tabular-nums; }\n.stat .l { font-size: var(--text-xs); color: var(--text-muted); }\n.small { font-size: var(--text-sm); margin: 0 0 var(--space-2); }\n\n/* --- Activity heatmap -------------------------------------------------- */\n.heat-wrap { overflow-x: auto; }\n.heat { display: grid; grid-template-rows: repeat(7, 12px); grid-auto-flow: column; grid-auto-columns: 12px; gap: 3px; }\n.heat i, .heat-legend i { width: 12px; height: 12px; border-radius: 2px; display: block; background: var(--heat-0); }\n.heat i.l1, .heat-legend i.l1 { background: var(--heat-1); }\n.heat i.l2, .heat-legend i.l2 { background: var(--heat-2); }\n.heat i.l3, .heat-legend i.l3 { background: var(--heat-3); }\n.heat i.l4, .heat-legend i.l4 { background: var(--heat-4); }\n.heat-legend { display: flex; gap: 4px; align-items: center; justify-content: flex-end; font-family: var(--font-mono); font-size: var(--text-xs); color: var(--text-muted); margin-top: 6px; }\n\n/* --- Two columns, growth line, horizontal bars ------------------------- */\n.two-col { display: grid; grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); gap: var(--space-6); }\n.growth { width: 100%; height: auto; display: block; }\n.growth .axis { stroke: var(--line-strong); }\n.growth .area { fill: var(--accent-soft); }\n.growth .line { fill: none; stroke: var(--accent); stroke-width: 2.5; stroke-linejoin: round; stroke-dasharray: 2000; animation: draw 2.6s ease-out both; }\n.growth .now { fill: var(--accent); animation: pulse 2s ease-in-out infinite; }\n.growth text { fill: var(--text-muted); font-family: var(--font-mono); font-size: 11px; }\n.hbar { display: grid; grid-template-columns: 130px 1fr 52px; gap: 10px; align-items: center; font-size: var(--text-sm); padding: 4px 0; }\n.hbar .track { height: 8px; background: var(--bg-raised); border-radius: 4px; overflow: hidden; }\n.hbar .fill { display: block; height: 100%; background: var(--accent); border-radius: 4px; transform-origin: left; animation: grow 1.2s cubic-bezier(.2,.8,.2,1) both; }\n.hbar .fill.alt { background: var(--chart-alt); }\n.hbar .num { text-align: right; font-family: var(--font-mono); font-size: var(--text-xs); color: var(--text-muted); }\n.cols { height: 120px; display: flex; gap: 4px; align-items: flex-end; border-bottom: 1px solid var(--line-strong); margin-top: var(--space-2); }\n.cols span { flex: 1; height: 100%; display: flex; flex-direction: column-reverse; align-items: center; }\n.cols b { display: block; width: 100%; background: var(--chart-alt); border-radius: 2px 2px 0 0; transform-origin: bottom; animation: rise 1s cubic-bezier(.2,.8,.2,1) both; }\n.cols em { font-style: normal; font-family: var(--font-mono); font-size: 10px; color: var(--text-muted); }\n\n/* --- Topic cloud ------------------------------------------------------- */\n.cloud { display: flex; flex-wrap: wrap; gap: 6px 16px; align-items: baseline; }\n.cloud span { color: var(--text-strong); line-height: 1.3; }\n.cloud sup { font-family: var(--font-mono); font-size: 10px; color: var(--text-muted); margin-left: 2px; }\n\n@keyframes draw { from { stroke-dashoffset: 2000; } to { stroke-dashoffset: 0; } }\n@keyframes grow { from { transform: scaleX(0); } to { transform: scaleX(1); } }\n\n\n/* --- Daily journal ----------------------------------------------------- */\n.journal { background: var(--bg-raised); border: 1px solid var(--line); border-radius: var(--radius-lg); padding: var(--space-4); margin-bottom: var(--space-6); overflow: hidden; }\n.j-head { display: flex; align-items: center; gap: var(--space-3); margin-bottom: var(--space-3); }\n.j-title { flex: 1; text-align: center; }\n.j-date { font-family: var(--font-display); font-size: 22px; color: var(--text-strong); }\n.j-nav { width: 44px; height: 44px; border-radius: 50%; border: 1px solid var(--line-strong); background: var(--bg); color: var(--text); font-size: 22px; cursor: pointer; }\n.j-nav:disabled { opacity: .3; cursor: default; }\n.j-top { display: flex; flex-wrap: wrap; gap: var(--space-4); align-items: center; }\n.ring-wrap { position: relative; width: 96px; height: 96px; flex: 0 0 96px; }\n.ring { width: 96px; height: 96px; transform: rotate(-90deg); display: block; }\n.ring .trk { fill: none; stroke: var(--line); stroke-width: 9; }\n.ring .val { fill: none; stroke: var(--accent); stroke-width: 9; stroke-linecap: round; transition: stroke-dashoffset .8s cubic-bezier(.2,.8,.2,1); }\n.j-score { position: absolute; inset: 0; display: flex; flex-direction: column; align-items: center; justify-content: center; }\n.j-score .v { font-size: 26px; color: var(--text-strong); line-height: 1; }\n.j-score .l { font-size: 10px; color: var(--text-muted); }\n.j-delta { font-family: var(--font-mono); font-size: var(--text-xs); margin-bottom: 4px; }\n.j-headline { flex: 1 1 260px; font-family: var(--font-display); font-size: 21px; color: var(--text-strong); line-height: 1.3; }\n.j-themes { display: flex; gap: 6px; flex-wrap: wrap; margin-top: 8px; font-family: var(--font-body); }\n.j-themes span { font-size: var(--text-xs); color: var(--accent-text); background: var(--accent-soft); border-radius: var(--radius-round); padding: 2px 10px; }\n.j-chips { display: grid; grid-template-columns: repeat(auto-fit, minmax(96px, 1fr)); gap: 1px; background: var(--line); border: 1px solid var(--line); border-radius: var(--radius-md); overflow: hidden; margin: var(--space-4) 0; }\n.chip { background: var(--bg); padding: var(--space-2); }\n.chip .v { font-size: 20px; color: var(--text-strong); font-variant-numeric: tabular-nums; }\n.chip .l { font-size: var(--text-xs); color: var(--text-muted); }\n.chip .dd { font-family: var(--font-mono); font-size: var(--text-xs); min-height: 1em; }\n.up { color: var(--accent-2); } .down { color: var(--text-muted); } .flat { color: var(--text-muted); }\n.j-lists ul { margin-top: 4px; }\n.flip-l { animation: flipL .45s ease both; } .flip-r { animation: flipR .45s ease both; }\n@keyframes flipL { from { opacity: 0; transform: translateX(-24px) rotateY(8deg); } to { opacity: 1; transform: none; } }\n@keyframes flipR { from { opacity: 0; transform: translateX(24px) rotateY(-8deg); } to { opacity: 1; transform: none; } }\n\n/* --- Scoreboard -------------------------------------------------------- */\n.scoreboard { margin-bottom: var(--space-6); }\n.sb-stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(160px, 1fr)); gap: var(--space-3); margin-bottom: var(--space-3); }\n.sb-stat .v { font-size: 30px; color: var(--text-strong); line-height: 1.1; }\n.sb-stat .v small { font-size: 14px; color: var(--text-muted); }\n.sb-stat .l { font-size: var(--text-xs); color: var(--text-muted); }\n.sb-bars { height: 90px; display: flex; gap: 3px; align-items: flex-end; border-bottom: 1px solid var(--line-strong); }\n.sb-bars span { flex: 1; background: var(--chart-bar-quiet); border-radius: 2px 2px 0 0; transform-origin: bottom; animation: rise 1s cubic-bezier(.2,.8,.2,1) both; }\n.sb-bars span.yday { background: var(--accent); }\n.sb-bars span.today { background: repeating-linear-gradient(45deg, var(--chart-bar-quiet), var(--chart-bar-quiet) 3px, transparent 3px, transparent 6px); }\n.sb-lower { margin-top: var(--space-4); }\n.lb-row { display: grid; grid-template-columns: 26px 1fr auto; gap: 10px; align-items: center; padding: 7px 0; border-bottom: 1px solid var(--line); font-size: var(--text-sm); }\n.lb-row .rank { font-family: var(--font-mono); color: var(--text-muted); }\n.lb-row .num { font-family: var(--font-mono); }\n.lb-row.me .who { color: var(--text-strong); font-weight: 600; }\n.lb-row.empty .who { color: var(--text-muted); border: 1px dashed var(--line-strong); border-radius: var(--radius-sm); padding: 2px 8px; justify-self: start; }\n.sb-how { margin-top: var(--space-3); font-size: var(--text-sm); color: var(--text-muted); }\n.sb-how summary { cursor: pointer; color: var(--accent-text); }\n\n/* --- Footer ------------------------------------------------------------ */\n.foot { margin-top: var(--space-8); padding-top: var(--space-3); border-top: 1px solid var(--line); font-family: var(--font-mono); font-size: var(--text-xs); color: var(--text-muted); }\n\n/* --- Motion (respects reduced-motion) ---------------------------------- */\n@keyframes pulse { 0%,100% { opacity: .35; } 50% { opacity: 1; } }\n@keyframes blink { 50% { opacity: 0; } }\n@keyframes rise { from { transform: scaleY(0); } to { transform: scaleY(1); } }\n@keyframes float { 0%,100% { transform: translate(0,0); } 50% { transform: translate(3px,-4px); } }\n@media (prefers-reduced-motion: reduce) { * { animation: none !important; } }\n\n.note { max-width: 100%; }\n.lede { font-size: var(--text-lg); color: var(--text-muted); margin: -8px 0 var(--space-6); }\n.pnote { padding: var(--space-3) 0; border-bottom: 1px solid var(--line); }\n.pn-title { font-family: var(--font-display); font-size: 19px; color: var(--text-strong); }\n.pn-ex { color: var(--text); font-size: var(--text-sm); }\n.pn-date { font-family: var(--font-mono); font-size: var(--text-xs); color: var(--text-muted); }\n';

// src/render.ts
var big = (n) => n >= 1e9 ? (n / 1e9).toFixed(2).replace(/\.?0+$/, "") + "B" : n >= 1e6 ? (n / 1e6).toFixed(1).replace(/\.0$/, "") + "M" : n >= 1e3 ? Math.round(n / 1e3) + "K" : String(n);
function inline(t) {
  const parts = [];
  let last = 0;
  const rx = /\[\[([^|\]]+)\|(https?:\/\/[^\]\s]+)\]\]|\[([^\]]+)\]\((https?:\/\/[^)\s]+)\)|\*\*([^*]+)\*\*/g;
  for (let m; m = rx.exec(t); ) {
    parts.push(esc(t.slice(last, m.index)));
    if (m[5]) parts.push(`<b>${esc(m[5])}</b>`);
    else parts.push(`<a href="${esc(m[2] || m[4])}" rel="noopener">${esc(m[1] || m[3])}</a>`);
    last = m.index + m[0].length;
  }
  return parts.join("") + esc(t.slice(last));
}
function graphSvg(nodes, name) {
  if (!nodes.length) return "";
  const top = Math.max(1, ...nodes.map((x) => x.n)), order = [...nodes].sort((a, b) => b.n - a.n);
  const out = order.map((nd, i) => {
    const a = i / order.length * Math.PI * 2, r = i % 2 === 0 ? 64 : 96;
    const x = 130 + Math.cos(a) * r, y = 120 + Math.sin(a) * r * 0.85, size = 2.5 + 6.5 * Math.sqrt(nd.n / top);
    return { ...nd, x: x.toFixed(1), y: y.toFixed(1), ty: (y + size + 9).toFixed(1), r: size.toFixed(1), hot: nd.n >= top * 0.35, d: (-i * 0.3).toFixed(1) };
  });
  return `<svg viewBox="0 0 260 240" role="img" aria-label="Notes connected to ${esc(name)}">${out.map((n) => `<line class="edge" x1="130" y1="120" x2="${n.x}" y2="${n.y}"></line>`).join("")}${out.map((n) => `<g class="float" style="animation-delay:${n.d}s"><circle class="node${n.hot ? " hot" : ""}" cx="${n.x}" cy="${n.y}" r="${n.r}"><title>${esc(n.t)}: ${n.n}</title></circle><text x="${n.x}" y="${n.ty}" text-anchor="middle">${esc(n.t)}</text></g>`).join("")}<circle class="center" cx="130" cy="120" r="9"></circle></svg>`;
}
var esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
var fmt = (n) => n.toLocaleString("en-US");
function scored(daily) {
  return daily.map((d, i) => {
    const score = activityScore(d.counts);
    const prev = i ? activityScore(daily[i - 1].counts) : null;
    return { ...d, score, delta: prev ? Math.round((score - prev) / prev * 100) : null };
  });
}
function renderProfile(p) {
  const s = p.sections;
  const days = scored(p.daily);
  const labels = { meetings: "Meetings", emails: "Emails sent", prompts: "AI sessions", commits: "Commits", notes: "Notes", docs: "Docs filed" };
  const present = Object.keys(labels).filter((k) => days.some((d) => d.counts[k]));
  const journal = days.map((d, i) => ({
    date: d.date,
    label: (/* @__PURE__ */ new Date(d.date + "T12:00:00")).toLocaleDateString("en-US", { weekday: "long", month: "short", day: "numeric" }),
    score: d.score,
    delta: d.delta,
    headline: d.headline || "",
    focus: d.focus || [],
    wins: d.wins || [],
    themes: d.themes || [],
    chips: present.map((k) => ({ k: labels[k], v: d.counts[k] || 0, d: i ? (d.counts[k] || 0) - (days[i - 1].counts[k] || 0) : null }))
  }));
  const scores = days.map((d) => d.score);
  const yday = days.length > 1 ? days[days.length - 2] : days[days.length - 1];
  let streak = 0;
  const thresh = Math.max(20, (scores.slice().sort((a, b) => a - b)[Math.floor(scores.length / 2)] || 0) * 0.6);
  for (const sc of scores.slice(0, -1).reverse()) {
    if (sc >= thresh) streak++;
    else break;
  }
  const ranked = days.slice(0, -1).slice().sort((a, b) => b.score - a.score);
  const yrank = yday ? ranked.findIndex((d) => d.date === yday.date) + 1 : 0;
  const smax = Math.max(1, ...scores);
  const last7 = scores.slice(-8, -1), prev7 = scores.slice(-15, -8);
  const avg = (a) => a.length ? Math.round(a.reduce((x, y) => x + y, 0) / a.length) : 0;
  const trend = avg(prev7) ? Math.round((avg(last7) - avg(prev7)) / avg(prev7) * 100) : 0;
  const tmax = Math.max(1, ...p.topics.map((t) => t[1]));
  const parts = [];
  parts.push(`<!doctype html><html lang="en"${p.theme === "light" ? ' data-theme="light"' : ""}><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>${esc(p.name)}</title>
<meta name="robots" content="noindex, nofollow"><meta name="generator" content="Caldera for Obsidian">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Source+Serif+4:opsz,wght@8..60,400;8..60,600&family=IBM+Plex+Sans:wght@400;500;600&family=IBM+Plex+Mono:wght@400&display=swap">
<link rel="stylesheet" href="assets/theme.css"><link rel="stylesheet" href="assets/profile.css"></head><body>
<div class="tabs"><span class="tab is-active">${esc(p.name)}.md</span><span class="spacer"></span><span class="sync"><span class="dot"></span>synced from vault <span id="ago" data-ts="${esc(p.updated)}">just now</span></span></div>
<div class="shell">`);
  const sideOn = s.sidebar !== false && !!p.tree?.length, railOn = s.rail !== false && (!!p.graph?.length || !!p.backlinks?.length);
  if (sideOn) parts.push(`<nav class="sidebar tree" aria-label="Vault"><span class="label">Vault</span>${p.tree.map((r) => `<div class="tree-row${r.child ? " child" : ""}${r.current ? " is-current" : ""}"><span>${r.child ? "" : "&#9662; "}${esc(r.name)}</span></div>`).join("")}</nav>`);
  parts.push(`<main class="note">`);
  if (p.banner || p.avatar) parts.push(`<div class="banner">${p.banner ? `<img class="cover" src="${esc(p.banner)}" alt="">` : ""}${p.avatar ? `<img class="avatar" src="${esc(p.avatar)}" alt="${esc(p.name)}">` : ""}</div>`);
  parts.push(`<div class="page"><div class="crumb">People / ${esc(p.name)}.md${p.handle ? " / @" + esc(p.handle) : ""}</div>
<h1 class="title">${esc(p.name)}<span class="caret">|</span></h1>${p.headline ? `<p class="lede">${esc(p.headline)}</p>` : ""}`);
  if (s.journal && journal.length) parts.push(`<section class="journal" aria-label="Daily journal"><div class="j-head"><button class="j-nav" id="jprev" aria-label="Previous day">&#8249;</button>
<div class="j-title"><div class="label">Daily journal</div><div class="j-date" id="jdate"></div></div><button class="j-nav" id="jnext" aria-label="Next day">&#8250;</button></div>
<div class="j-body" id="jbody" aria-live="polite"></div></section><script id="journal-data" type="application/json">${JSON.stringify(journal).replace(/</g, "\\u003c")}<\/script>`);
  if (s.scoreboard && days.length > 2) parts.push(`<section class="scoreboard"><div class="sb-stats">
<div class="sb-stat"><div class="v">${streak}<small> days</small></div><div class="l">active streak</div></div>
<div class="sb-stat"><div class="v">#${yrank}</div><div class="l">yesterday's rank of ${days.length - 1} days</div></div>
<div class="sb-stat"><div class="v">${avg(last7)}</div><div class="l">7-day average, ${trend >= 0 ? `<span class="up">&#9650; ${trend}%</span>` : `<span class="down">&#9660; ${-trend}%</span>`} vs prior week</div></div></div>
<div class="sb-bars" role="img" aria-label="Daily activity score">${days.slice(-30).map((d, i, a) => `<span class="${i === a.length - 2 ? "yday" : i === a.length - 1 ? "today" : ""}" style="height:${Math.max(2, Math.round(d.score / smax * 100))}%" title="${d.date}: ${d.score}"></span>`).join("")}</div>
${(() => {
    const best = days.slice(0, -2).map((d, i) => ({ d, i })).sort((a, b) => b.d.score - a.d.score).slice(0, 5);
    const lb = [`<div class="lb-row me"><span class="rank">1</span><span class="who">You</span><span class="num">${fmt(days.slice(-8, -1).reduce((x, d) => x + d.score, 0))}</span></div>`].concat([2, 3, 4].map((r) => `<div class="lb-row empty"><span class="rank">${r}</span><span class="who">Invite a friend</span><span class="num">-</span></div>`));
    return `<div class="two-col sb-lower"><div><div class="label">Leaderboard / points this week</div>${lb.join("")}</div><div><div class="label">Your best other days</div>${best.map((b, k) => `<div class="lb-row"><span class="rank">${k + 1}</span><span class="who">${esc((/* @__PURE__ */ new Date(b.d.date + "T12:00:00Z")).toLocaleDateString("en-US", { weekday: "short", month: "short", day: "numeric", timeZone: "UTC" }))}</span><span class="num">${b.d.score}</span></div>`).join("")}</div></div>`;
  })()}
<details class="sb-how"><summary>How the score works</summary>Weighted daily counts: ${Object.entries(ACTIVITY_WEIGHTS).map(([k, w]) => `${labels[k] || k} x${w}`).join(", ")}. Bulk imports are capped. Counts only.</details></section>`);
  if (s.properties && p.properties.length) parts.push(`<dl class="props">${p.properties.map(([k, v]) => `<dt>${esc(k)}</dt><dd>${esc(v)}</dd>`).join("")}</dl>`);
  if (s.numbers) parts.push(`<div class="stat-strip">${[[fmt(p.stats.notes), "notes"], [(p.stats.words / 1e6).toFixed(2) + "M", "words"], [fmt(p.stats.links), "links between notes"], [String(p.stats.activeDays), "active days, 26 weeks"], ...p.extraNumbers || []].map(([v, l]) => `<div class="stat"><div class="v">${v}</div><div class="l">${l}</div></div>`).join("")}</div>`);
  if (s.summary !== false && p.summary) parts.push(`<div class="callout"><div class="callout-title">Summary</div>${inline(p.summary)}</div>`);
  if (s.now !== false && p.now?.length) parts.push(`<h2>Now</h2><ul class="bullets">${p.now.map((x) => `<li>${inline(x)}</li>`).join("")}</ul>`);
  if (s.activity !== false && p.heat?.length) {
    const lvl = (n) => n === 0 ? 0 : n < 5 ? 1 : n < 30 ? 2 : n < 200 ? 3 : 4;
    const pad = ((/* @__PURE__ */ new Date(p.heat[0].date + "T12:00:00Z")).getUTCDay() + 6) % 7;
    parts.push(`<h2>Activity</h2><p class="small muted">Every day the vault learned something in the last 26 weeks: notes written and changed${p.extraNumbers?.length ? ", documents filed" : ""}.</p><div class="heat-wrap"><div class="heat" role="img" aria-label="Activity, last 26 weeks">${"<i></i>".repeat(pad).replace(/<i>/g, '<i style="visibility:hidden">')}${p.heat.map((c) => `<i class="l${lvl(c.n)}" title="${esc(c.date)}: ${c.n}"></i>`).join("")}</div></div><div class="heat-legend">less <i class="l1"></i><i class="l2"></i><i class="l3"></i><i class="l4"></i> more</div>`);
  }
  const growthOn = s.growth !== false && (p.growth?.length || 0) > 1, knowsOn = s.knows !== false && !!p.knows?.length;
  if (growthOn || knowsOn) {
    let g = "";
    if (growthOn) {
      const gp = p.growth, gmax = Math.max(1, gp[gp.length - 1].total), W = 600, H = 180;
      const gx = (i) => 30 + i * (W - 40) / Math.max(1, gp.length - 1), gy = (v) => 10 + (H - 30) * (1 - v / gmax);
      const line = gp.map((x, i) => `${gx(i).toFixed(1)},${gy(x.total).toFixed(1)}`).join(" ");
      const first = (/* @__PURE__ */ new Date(gp[0].week + "T12:00:00Z")).toLocaleDateString("en-US", { month: "short", year: "numeric", timeZone: "UTC" });
      g = `<div><h2>Growth</h2><svg class="growth" viewBox="0 0 ${W} ${H}" role="img" aria-label="Notes over time, ${fmt(gmax)} now"><line class="axis" x1="30" y1="${H - 20}" x2="${W - 10}" y2="${H - 20}"></line><path class="area" d="M${gx(0).toFixed(1)},${H - 20} L${line.replace(/ /g, " L")} L${gx(gp.length - 1).toFixed(1)},${H - 20} Z"></path><polyline class="line" points="${line}"></polyline><circle class="now" cx="${gx(gp.length - 1).toFixed(1)}" cy="${gy(gmax).toFixed(1)}" r="5"></circle><text x="30" y="${H - 4}">${esc(first)}</text><text x="${W - 10}" y="${H - 4}" text-anchor="end">${fmt(gmax)} notes</text></svg></div>`;
    }
    const kmax = Math.max(1, ...(p.knows || []).map((k2) => k2[1]));
    const k = knowsOn ? `<div><h2>What it knows</h2>${p.knows.map(([l, n]) => `<div class="hbar"><span>${esc(l)}</span><span class="track"><span class="fill" style="width:${(n / kmax * 100).toFixed(1)}%"></span></span><span class="num">${fmt(n)}</span></div>`).join("")}</div>` : "";
    parts.push(`<div class="two-col">${g}${k}</div>`);
  }
  if (s.inbox !== false && p.inbox?.kinds?.length) {
    const ib = p.inbox, kmax = Math.max(1, ...ib.kinds.map((k) => k[1])), total = ib.total ?? ib.kinds.reduce((a, k) => a + k[1], 0);
    const se = ib.series, smax2 = Math.max(1, ...(se?.weeks || []).map((w) => w[1]));
    parts.push(`<h2>Inbox to knowledge</h2><p class="small muted">${esc(ib.note || `Every email attachment is read, summarized and linked into the vault overnight. ${fmt(total)} documents so far, by kind. Contents stay private.`)}</p><div class="two-col"><div>${ib.kinds.map(([l, n]) => `<div class="hbar"><span>${esc(l)}</span><span class="track"><span class="fill alt" style="width:${(n / kmax * 100).toFixed(1)}%"></span></span><span class="num">${fmt(n)}</span></div>`).join("")}</div>${se?.weeks?.length ? `<div><div class="label">${esc(se.label)} / ${fmt(se.weeks.reduce((a, w) => a + w[1], 0))} in ${se.weeks.length} weeks</div><div class="cols">${se.weeks.map(([l, n]) => `<span title="${esc(l)}: ${n}"><b style="height:${Math.max(3, n / smax2 * 100).toFixed(1)}%"></b><em>${n || ""}</em></span>`).join("")}</div><div class="bars-legend"><span>${esc(se.weeks[0][0])}</span><span>this week</span></div></div>` : ""}</div>`);
  }
  if (s.topics && p.topics.length) parts.push(`<h2>Topics</h2><div class="cloud">${p.topics.map(([t, n]) => `<span style="font-size:${(13 + n / tmax * 15).toFixed(1)}px">${esc(t)}<sup>${n}</sup></span>`).join("")}</div>`);
  if (s.projects !== false && p.projects?.length) {
    const hasC = p.projects.some((x) => x.commits);
    parts.push(`<h2>Projects</h2><div class="table-wrap"><table class="data"><thead><tr><th>Project</th><th>status</th>${hasC ? '<th class="num">commits</th>' : ""}<th>link</th></tr></thead><tbody>${p.projects.map((x) => `<tr><td>${esc(x.name)}</td><td>${esc(x.status)}</td>${hasC ? `<td class="num">${x.commits ? fmt(x.commits) : ""}</td>` : ""}<td>${/^https?:\/\//.test(x.url) ? `<a href="${esc(x.url)}" rel="noopener">${esc(x.url.replace(/^https?:\/\//, "").replace(/\/$/, ""))}</a>` : ""}</td></tr>`).join("")}</tbody></table></div>`);
  }
  if (s.code !== false && p.code && p.code.commits > 0) {
    const c = p.code, wk = c.weekly || [], f = Math.max(0, wk.findIndex((x) => x > 0)), w2 = wk.slice(f), peak = Math.max(1, ...w2);
    parts.push(`<h2>Code</h2><p class="small"><b>${fmt(c.commits)}</b> commits across <b>${fmt(c.repos)}</b> repositories in the last year.${c.languages?.length ? ` Mostly ${esc(c.languages.slice(0, -1).join(", "))}${c.languages.length > 1 ? " and " : ""}${esc(c.languages[c.languages.length - 1])}.` : ""}${c.url && /^https?:\/\//.test(c.url) ? ` <a href="${esc(c.url)}" rel="noopener">${esc(c.url.replace(/^https?:\/\//, ""))}</a>` : ""}</p>${w2.length ? `<div class="bars" role="img" aria-label="Commits per week">${w2.map((x) => `<span class="${x >= peak * 0.5 ? "" : "quiet"}" style="height:${Math.max(2, x / peak * 100).toFixed(1)}%" title="${x}"></span>`).join("")}</div><div class="bars-legend"><span>${esc(c.start || "")}</span><span>peak week: ${fmt(peak)}</span><span>this week</span></div>` : ""}`);
  }
  if (s.ai !== false && p.ai && p.ai.total > 0) {
    const a = p.ai, td = days.map((d) => ({ date: d.date, n: d.tokens || 0 })), tpeak = Math.max(1, ...td.map((x) => x.n));
    const share = (n) => a.total ? Math.round(n / a.total * 1e3) / 10 : 0;
    const bars = (rows, alt = false) => {
      const m = Math.max(1, ...rows.map((r) => r[1]));
      return rows.map(([l, n]) => `<div class="hbar"><span>${esc(l)}</span><span class="track"><span class="fill${alt ? " alt" : ""}" style="width:${(n / m * 100).toFixed(1)}%"></span></span><span class="num" title="${fmt(n)} tokens">${share(n) >= 0.1 ? share(n) + "%" : "&lt;0.1%"}</span></div>`).join("");
    };
    parts.push(`<h2>AI usage</h2><p class="small"><b>${big(a.total)}</b> tokens across <b>${a.models.length}</b> model${a.models.length === 1 ? "" : "s"} in the last ${a.window_days || td.length} days.${a.note ? ` <span class="muted">${esc(a.note)}</span>` : ""}</p>${td.some((x) => x.n) ? `<div class="bars" role="img" aria-label="AI tokens per day">${td.map((x) => `<span class="${x.n >= tpeak * 0.5 ? "" : "quiet"}" style="height:${Math.max(2, x.n / tpeak * 100).toFixed(1)}%" title="${esc(x.date)}: ${big(x.n)} tokens"></span>`).join("")}</div><div class="bars-legend"><span>${esc(td[0]?.date || "")}</span><span>peak day: ${big(tpeak)}</span><span>today</span></div>` : ""}<div class="two-col" style="margin-top:var(--space-4)"><div><div class="label">Models / share of tokens</div>${bars(a.models)}</div>${a.providers?.length ? `<div><div class="label">Providers</div>${bars(a.providers, true)}</div>` : ""}</div>`);
  }
  if (s.timeline !== false && p.timeline?.length) parts.push(`<h2>Timeline</h2><div class="timeline">${p.timeline.map(([y, t]) => `<div class="row"><span class="year">${esc(y)}</span><span>${inline(t)}</span></div>`).join("")}</div>`);
  if (s.notes && p.publicNotes.length) parts.push(`<h2>Notes</h2>${p.publicNotes.map((n) => `<div class="pnote"><div class="pn-title">${esc(n.title)}</div><div class="pn-ex">${esc(n.excerpt)}</div><div class="pn-date">${esc(n.updated.slice(0, 10))}</div></div>`).join("")}`);
  if (s.asks && (p.asks.length || p.offers.length)) parts.push(`<h2>Help exchange</h2><div class="hx-grid">
<div class="hx-card"><div class="label">I could use help with</div>${p.asks.map((a) => `<div class="hx-row"><span>${esc(a.title)}</span><span class="bounty">+${a.bounty}</span></div>`).join("") || '<div class="muted">Nothing right now</div>'}</div>
<div class="hx-card"><div class="label">I can help with</div>${p.offers.map((o) => `<div class="hx-row"><span>${esc(o.title)}</span></div>`).join("") || '<div class="muted">Ask me</div>'}</div></div>`);
  if (s.social && p.social) parts.push(`<div class="stat-strip">${[[fmt(p.social.friends), "friends"], [String(p.social.gravity), "gravity"], [fmt(p.social.credits), "help credits"]].map(([v, l]) => `<div class="stat"><div class="v">${v}</div><div class="l">${l}</div></div>`).join("")}</div>`);
  if (s.links && p.links.length) parts.push(`<h2>Elsewhere</h2><ul class="bullets">${p.links.map(([l, u]) => `<li><a href="${esc(u)}" rel="noopener">${esc(l)}</a></li>`).join("")}</ul>`);
  parts.push(`<div class="foot">Grown from an Obsidian vault with Caldera. Updated ${esc(p.updated.slice(0, 16).replace("T", " "))} UTC. <a href="${esc((p.hub || "https://caldera.social").replace(/\/$/, ""))}/guide.html" target="_blank" rel="noopener">Your page? How to edit it</a></div></div></main>`);
  if (railOn) parts.push(`<aside class="rail">${p.graph?.length ? `<div class="graph"><div class="label">${esc(p.graphLabel || "Graph")}</div>${graphSvg(p.graph, p.name)}</div>` : ""}${p.backlinks?.length ? `<div><div class="label">${esc(p.backlinkLabel || "Backlinks")}</div>${p.backlinks.map(([t, c]) => `<div class="backlink"><span>${esc(t)}</span><div class="ctx">${esc(c)}</div></div>`).join("")}</div>` : ""}</aside>`);
  parts.push(`</div>`);
  parts.push(`<script>${CLIENT_JS}<\/script></body></html>`);
  return { "index.html": parts.join("\n"), "assets/theme.css": theme_default, "assets/profile.css": PROFILE_CSS };
}
var CLIENT_JS = `(function(){var a=document.getElementById('ago');if(a){var t=Date.parse(a.dataset.ts);var f=function(){var m=Math.max(0,Math.round((Date.now()-t)/60000));a.textContent=m<60?m+'m ago':Math.floor(m/60)+'h '+(m%60)+'m ago'};f();setInterval(f,30000)}
var el=document.getElementById('journal-data');if(!el)return;var days=JSON.parse(el.textContent);if(!days.length)return;var i=Math.max(0,days.length-2);
var body=document.getElementById('jbody'),dt=document.getElementById('jdate'),pv=document.getElementById('jprev'),nx=document.getElementById('jnext');
var esc=function(s){return String(s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})};
var dl=function(d){return d==null?'':d>0?'<span class="up">&#9650; '+d+'</span>':d<0?'<span class="down">&#9660; '+(-d)+'</span>':'<span class="flat">=</span>'};
var mx=Math.max.apply(null,days.map(function(x){return x.score}).concat([1]));
function r(dir){var d=days[i],L=days.length;dt.textContent=(i===L-1?'Today so far / ':i===L-2?'Yesterday / ':'')+d.label;var C=2*Math.PI*42,p=Math.min(1,d.score/mx);
var sd=d.delta==null?'':(d.delta>=0?'<span class="up">&#9650; '+d.delta+'%</span>':'<span class="down">&#9660; '+(-d.delta)+'%</span>')+' vs day before';
var h='<div class="j-top"><div class="ring-wrap"><svg class="ring" viewBox="0 0 100 100" aria-hidden="true"><circle class="trk" cx="50" cy="50" r="42"></circle><circle class="val" cx="50" cy="50" r="42" style="stroke-dasharray:'+C+';stroke-dashoffset:'+(C*(1-p))+'"></circle></svg><div class="j-score"><div class="v">'+d.score+'</div><div class="l">score</div></div></div>'+
'<div class="j-headline">'+(sd?'<div class="j-delta">'+sd+'</div>':'')+(d.headline?esc(d.headline):'<span class="muted">No journal for this day. Activity only.</span>')+(d.themes.length?'<div class="j-themes">'+d.themes.map(function(t){return'<span>'+esc(t)+'</span>'}).join('')+'</div>':'')+'</div></div>';
if(d.chips.length)h+='<div class="j-chips">'+d.chips.map(function(c){return'<div class="chip"><div class="v">'+c.v+'</div><div class="l">'+esc(c.k)+'</div><div class="dd">'+dl(c.d)+'</div></div>'}).join('')+'</div>';
if(d.focus.length||d.wins.length){h+='<div class="two-col j-lists">';if(d.focus.length)h+='<div><div class="label">Focus</div><ul class="bullets">'+d.focus.map(function(x){return'<li>'+esc(x)+'</li>'}).join('')+'</ul></div>';if(d.wins.length)h+='<div><div class="label">Wins</div><ul class="bullets">'+d.wins.map(function(x){return'<li>'+esc(x)+'</li>'}).join('')+'</ul></div>';h+='</div>'}
body.innerHTML=h;body.classList.remove('flip-l','flip-r');void body.offsetWidth;if(dir)body.classList.add(dir<0?'flip-l':'flip-r');pv.disabled=i===0;nx.disabled=i===L-1}
pv.onclick=function(){if(i>0){i--;r(-1)}};nx.onclick=function(){if(i<days.length-1){i++;r(1)}};document.addEventListener('keydown',function(e){if(e.key==='ArrowLeft')pv.onclick();if(e.key==='ArrowRight')nx.onclick()});r(0)})();`;

// src/profile-file.ts
var import_obsidian3 = require("obsidian");
var PROFILE_FILE = "Caldera/profile.md";
var pair = (v) => {
  const [a, ...b] = String(v ?? "").split("|");
  const k = a.trim(), val = b.join("|").trim();
  return k && val ? [k, val] : null;
};
var pairs = (v) => Array.isArray(v) ? v.map(pair).filter(Boolean) : null;
function effectiveSettings(app, s) {
  const f = app.vault.getAbstractFileByPath(PROFILE_FILE);
  const fm = f instanceof import_obsidian3.TFile ? app.metadataCache.getFileCache(f)?.frontmatter : null;
  if (!fm) return s;
  const e = { ...s, sections: { ...s.sections } };
  if (typeof fm.name === "string" && fm.name.trim()) e.name = fm.name.trim();
  if (typeof fm.headline === "string") e.headline = fm.headline.trim();
  if (typeof fm.photo === "string") e.avatarPath = fm.photo.trim();
  if (typeof fm.banner === "string") e.bannerPath = fm.banner.trim();
  e.links = pairs(fm.links) ?? e.links;
  e.properties = pairs(fm.properties) ?? e.properties;
  const topics = pairs(fm.topics);
  if (topics) e.publicTopics = topics.map(([tag, label]) => [tag.replace(/^#/, ""), label]);
  if (fm.sections && typeof fm.sections === "object") for (const [k, v] of Object.entries(fm.sections)) e.sections[k] = v !== false;
  if (typeof fm.listed === "boolean") e.listed = fm.listed;
  if (Array.isArray(fm.sidebar)) e.tree = fm.sidebar.map((x) => {
    const [g, ...r] = String(x ?? "").split("|");
    return [g.trim(), r.join("|").trim()];
  }).filter(([g]) => g);
  if (Array.isArray(fm.graph)) e.graph = fm.graph.map((x) => String(x).trim()).filter(Boolean).slice(0, 20);
  e.backlinks = pairs(fm.backlinks) ?? e.backlinks;
  if (typeof fm.summary === "string") e.summary = fm.summary.trim();
  if (Array.isArray(fm.now)) e.now = fm.now.map((x) => String(x).trim()).filter(Boolean).slice(0, 8);
  e.timeline = pairs(fm.timeline) ?? e.timeline;
  e.projects = pairs(fm.projects) ?? e.projects;
  e.knows = pairs(fm.knows) ?? e.knows;
  return e;
}
var q = (v) => JSON.stringify(v);
function profileFileText(s, hubUrl) {
  const list = (rows) => rows.length ? rows.map((r) => `  - ${q(r)}`).join("\n") : "  []";
  return `---
name: ${q(s.name)}
headline: ${q(s.headline)}
photo: ${q(s.avatarPath)}
banner: ${q(s.bannerPath)}
links:
${list(s.links.map(([a, b]) => `${a} | ${b}`))}
properties:
${list(s.properties.map(([a, b]) => `${a} | ${b}`))}
topics:
${list(s.publicTopics.map(([a, b]) => `${a} | ${b}`))}
sections:
${Object.entries(s.sections).map(([k, v]) => `  ${k}: ${v}`).join("\n")}
listed: ${s.listed !== false}
summary: ${q(s.summary || "")}
now:
${list(s.now || [])}
timeline:
${list((s.timeline || []).map(([a, b]) => `${a} | ${b}`))}
projects:
${list((s.projects || []).map(([a, b]) => `${a} | ${b}`))}
knows:
${list((s.knows || []).map(([a, b]) => `${a} | ${b}`))}
sidebar:
${list((s.tree || []).map(([a, b]) => `${a} | ${b}`))}
graph:
${list(s.graph || [])}
backlinks:
${list((s.backlinks || []).map(([a, b]) => `${a} | ${b}`))}
---
# My Caldera profile

This note controls your public page at ${hubUrl.replace(/\/$/, "")}/@${s.handle}/ . Edit the properties above, or ask your AI agent to, and the page republishes itself about a minute after you save. **Everything above is public.**

- **name, headline** - shown at the top of your page.
- **photo, banner** - paths to images in this vault, e.g. \`Attachments/me.jpg\`.
- **links** - \`Label | https://...\`, one per line.
- **properties** - short facts, \`Label | value\` (e.g. \`Based in | Lisbon\`).
- **topics** - which of your tags may be counted publicly, \`tag | Label\`. Tags not listed are never shown.
- **sections** - switch parts of the page on or off: ${Object.keys(s.sections).join(", ")}.
- **listed** - \`true\` shows your card on the People page; \`false\` keeps the page link-only.
- **summary** - a short intro box. Links: \`[[Label|https://...]]\`, bold: \`**text**\`.
- **now** - what you're doing now, one line each.
- **timeline** - \`Year | what happened\`.
- **projects** - \`Name | status | https://link\`.
- **knows** - \`Label | vault folder\`; shows how many notes are in each folder (counts only).
- **sidebar** - the left column, \`Group | item, item\` (e.g. \`Projects | Garden app, Newsletter\`). Empty: your topics and public notes.
- **graph** - note names for the graph on the right, sized by how many of your notes link to each (only the count is published). Empty: your topics.
- **backlinks** - the list under the graph, \`Title | short context\`. Empty: your public notes.

Your handle and identity key live in Settings -> Caldera, never here. Guide: ${hubUrl.replace(/\/$/, "")}/guide.html
`;
}
async function ensureProfileFile(app, s, hubUrl) {
  const existing = app.vault.getAbstractFileByPath(PROFILE_FILE);
  if (existing instanceof import_obsidian3.TFile) return existing;
  if (!app.vault.getAbstractFileByPath("Caldera")) await app.vault.createFolder("Caldera").catch(() => {
  });
  return app.vault.create(PROFILE_FILE, profileFileText(s, hubUrl));
}

// src/main.ts
var VIEW = "caldera-panel";
var CalderaPlugin = class extends import_obsidian4.Plugin {
  constructor() {
    super(...arguments);
    this.pending = [];
    this.friends = [];
    this.social = { friends: 0, gravity: 0, credits: 0 };
    this.token = null;
    this.timers = [];
    // republish shortly after the owner (or their agent) edits Caldera/profile.md or the activity file
    this.publishTimer = null;
  }
  async onload() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
    this.addSettingTab(new CalderaSettingTab(this.app, this));
    this.registerView(VIEW, (leaf) => new CalderaView(leaf, this));
    this.addRibbonIcon("flame", "Caldera", () => this.openPanel());
    this.addCommand({ id: "preview", name: "Preview my public profile", callback: () => this.preview() });
    this.addCommand({ id: "publish", name: "Publish my profile", callback: () => this.publish() });
    this.addCommand({ id: "open", name: "Open my public profile", callback: () => this.openProfile() });
    this.addCommand({ id: "profile-file", name: "Edit my profile (open Caldera/profile.md)", callback: () => this.openProfileFile() });
    this.addCommand({ id: "edit-prompt", name: "Copy AI prompt: change my profile", callback: () => this.copyPrompt("edit") });
    this.addCommand({ id: "whats-new", name: "What's new in Caldera", callback: () => this.checkReleases(true) });
    this.addCommand({ id: "guide", name: "Open the Caldera guide", callback: () => window.open(this.settings.hubUrl.replace(/\/$/, "") + "/guide.html") });
    this.registerEvent(this.app.metadataCache.on("changed", (f) => {
      if (f.path === PROFILE_FILE) this.queuePublish("profile");
    }));
    this.registerEvent(this.app.vault.on("modify", (f) => {
      if (f.path === this.settings.activityFile) this.queuePublish("activity");
    }));
    this.addCommand({ id: "welcome", name: "Set up my profile (welcome)", callback: () => new WelcomeModal(this.app, this).open() });
    this.addCommand({ id: "export", name: "Export profile to a vault folder (self-host)", callback: () => this.exportToFolder() });
    this.addCommand({ id: "panel", name: "Open friends panel", callback: () => this.openPanel() });
    this.addCommand({ id: "sync", name: "Sync inbox now", callback: () => this.syncInbox(true) });
    this.addCommand({ id: "share", name: "Share this note with a friend", checkCallback: (check) => {
      const f = this.app.workspace.getActiveFile();
      if (!f) return false;
      if (!check) this.shareNote(f);
      return true;
    } });
    this.addCommand({ id: "delete", name: "Delete my profile from the hub", callback: () => new ConfirmModal(this.app, "Delete your Caldera profile from the hub? Your page, friendships, asks, offers, gravity and credits on the hub are erased. Your vault is not touched.", async () => {
      try {
        await this.send("profile.delete", {});
        new import_obsidian4.Notice("Your Caldera profile was deleted from the hub.");
      } catch (e) {
        new import_obsidian4.Notice(e.message);
      }
    }).open() });
    this.addCommand({ id: "agent-prompt", name: "Copy AI agent setup prompt (daily journal + activity)", callback: () => this.copyPrompt("setup") });
    this.addCommand({ id: "richer-prompt", name: "Copy AI prompt: make my profile richer", callback: () => this.copyPrompt("richer") });
    this.addCommand({ id: "ask", name: "Post an ask (I could use help with...)", callback: () => new AskModal(this.app, this, "ask").open() });
    this.addCommand({ id: "offer", name: "Post an offer (I can help with...)", callback: () => new AskModal(this.app, this, "offer").open() });
    this.app.workspace.onLayoutReady(() => {
      if (this.settings.identity && this.settings.handle) this.syncInbox(false);
      else if (!this.settings.welcomed) new WelcomeModal(this.app, this).open();
      window.setTimeout(() => this.checkReleases(false), 8e3);
    });
    this.timers.push(window.setInterval(() => this.settings.identity && this.syncInbox(false), 10 * 6e4));
    this.scheduleAutoPublish();
  }
  onunload() {
    this.timers.forEach((t) => window.clearInterval(t));
  }
  async saveSettings() {
    await this.saveData(this.settings);
  }
  async ensureIdentity(quiet = false) {
    if (!this.settings.identity) {
      this.settings.identity = newIdentity();
      await this.saveSettings();
      if (!quiet) new import_obsidian4.Notice("Caldera identity created. Export your recovery key from settings and keep it safe.");
    }
    return this.settings.identity;
  }
  scheduleAutoPublish() {
    if (this._auto) window.clearInterval(this._auto);
    const h = this.settings.autoPublishHours;
    if (h > 0) this._auto = window.setInterval(() => this.publish(true), h * 36e5);
  }
  // ---------------------------------------------------------------- hub client
  async api(method, path, body, auth = false) {
    const headers = { "content-type": "application/json" };
    if (auth) headers.authorization = "Bearer " + await this.authToken();
    const r = await (0, import_obsidian4.requestUrl)({ url: this.settings.hubUrl.replace(/\/$/, "") + path, method, headers, body: body ? JSON.stringify(body) : void 0, throw: false });
    if (r.status >= 400) throw new Error(r.json?.error || `hub error ${r.status}`);
    return r.json;
  }
  async send(type, body) {
    return this.api("POST", "/v1/envelopes", sign(await this.ensureIdentity(), type, body));
  }
  async authToken() {
    if (this.token && this.token.until > Date.now()) return this.token.value;
    const me = await this.ensureIdentity();
    const { nonce } = await this.api("POST", "/v1/auth/challenge", { id: me.id });
    const { token, expires_in } = await this.api("POST", "/v1/auth/verify", sign(me, "message", { nonce }));
    this.token = { value: token, until: Date.now() + (expires_in - 60) * 1e3 };
    return token;
  }
  // ---------------------------------------------------------------- profile
  /** Link counts are only right once Obsidian has resolved every link (it re-indexes after a restart). */
  linksResolved() {
    const mc = this.app.metadataCache;
    if (mc.resolved) return Promise.resolve();
    return new Promise((r) => {
      const ref = this.app.metadataCache.on("resolved", () => {
        this.app.metadataCache.offref(ref);
        r();
      });
      window.setTimeout(r, 9e4);
    });
  }
  async build() {
    await this.linksResolved();
    const eff = effectiveSettings(this.app, this.settings);
    const { data, files } = await collectProfile(this.app, eff, eff.sections.social ? this.social : void 0);
    data.hub = this.settings.hubUrl;
    const text = renderProfile(data);
    return { data, text, binaries: files, eff };
  }
  async openProfileFile() {
    const f = await ensureProfileFile(this.app, this.settings, this.settings.hubUrl);
    await this.app.workspace.getLeaf(true).openFile(f);
  }
  queuePublish(reason) {
    if (!this.settings.identity || !this.settings.handle) return;
    if (this.publishTimer) window.clearTimeout(this.publishTimer);
    this.publishTimer = window.setTimeout(async () => {
      this.publishTimer = null;
      const url = await this.publish(true);
      if (url && reason === "profile") new import_obsidian4.Notice("Caldera: your public page was updated.");
    }, 45e3);
  }
  // What's new: the hub's release feed, shown only to the owner, inside Obsidian
  async checkReleases(manual = false) {
    try {
      const r = await (0, import_obsidian4.requestUrl)({ url: this.settings.hubUrl.replace(/\/$/, "") + "/releases.json", throw: false });
      const list = r.status === 200 ? r.json?.releases || [] : [];
      if (!list.length) {
        if (manual) new import_obsidian4.Notice("Couldn't load release notes.");
        return;
      }
      const seen = list.findIndex((x) => x.version === this.settings.lastSeenRelease);
      if (!this.settings.lastSeenRelease && !manual) {
        this.settings.lastSeenRelease = list[0].version;
        await this.saveSettings();
        return;
      }
      const unseen = manual ? list.slice(0, 3) : list.slice(0, seen === -1 ? 1 : seen);
      if (!unseen.length) return;
      const open2 = () => {
        new WhatsNewModal(this.app, this, unseen).open();
        this.settings.lastSeenRelease = list[0].version;
        this.saveSettings();
      };
      if (manual) return open2();
      const frag = createFragment((f) => {
        f.createEl("b", { text: `Caldera ${unseen[0].version}: ` });
        f.appendText(unseen[0].title + " ");
        f.createEl("u", { text: "See what's new" });
      });
      const n = new import_obsidian4.Notice(frag, 2e4);
      n.noticeEl.addEventListener("click", open2);
    } catch {
      if (manual) new import_obsidian4.Notice("Couldn't load release notes.");
    }
  }
  async preview() {
    const { text, binaries } = await this.build();
    let html = text["index.html"].replace('<link rel="stylesheet" href="assets/theme.css">', `<style>${text["assets/theme.css"]}</style>`).replace('<link rel="stylesheet" href="assets/profile.css">', `<style>${text["assets/profile.css"]}</style>`);
    for (const [p, buf] of Object.entries(binaries)) {
      const mime = p.endsWith(".png") ? "image/png" : p.endsWith(".webp") ? "image/webp" : "image/jpeg";
      html = html.split(`src="${p}"`).join(`src="data:${mime};base64,${b64.enc(new Uint8Array(buf))}"`);
    }
    new PreviewModal(this.app, html).open();
  }
  async copyPrompt(kind) {
    const a = this.app.vault.adapter;
    const text = (kind === "richer" ? richerPrompt : kind === "edit" ? editPrompt : agentPrompt)({
      vaultPath: a instanceof import_obsidian4.FileSystemAdapter ? a.getBasePath() : void 0,
      hubUrl: this.settings.hubUrl,
      handle: this.settings.handle || void 0,
      activityFile: this.settings.activityFile,
      publicTopics: this.settings.publicTopics.map((t) => t[0]),
      installed: true
    });
    try {
      await navigator.clipboard.writeText(text);
      new import_obsidian4.Notice(kind === "richer" ? "Prompt copied. Paste it into your AI agent; it asks before making anything public." : "Agent prompt copied. Paste it into your AI agent (Claude Code, Codex, ...) and schedule it daily.");
    } catch {
      new PromptModal(this.app, text).open();
    }
  }
  async publish(quiet = false) {
    try {
      if (!this.settings.handle) throw new Error("Set a handle in Caldera settings first");
      const me = await this.ensureIdentity();
      const { data, text, binaries, eff } = await this.build();
      const manifest = sign(me, "profile.manifest", {
        name: data.name,
        handle: this.settings.handle,
        boxKey: me.boxPublic,
        headline: data.headline || "",
        photos: { avatar: data.avatar, banner: data.banner },
        links: data.links,
        sections: Object.keys(data.sections).filter((k) => data.sections[k]),
        stats: data.stats,
        daily: data.daily.map((d) => ({ date: d.date, score: activityScore(d.counts), headline: d.headline || "", counts: d.counts })),
        topics: data.topics,
        asks: data.asks,
        offers: data.offers,
        listed: eff.listed !== false,
        page: "index.html",
        updated: data.updated
      });
      const files = {};
      for (const [p, t] of Object.entries(text)) files[p] = b64.enc(new TextEncoder().encode(t));
      for (const [p, b] of Object.entries(binaries)) files[p] = b64.enc(new Uint8Array(b));
      const r = await this.api("POST", `/v1/profiles/${encodeURIComponent(me.id)}/bundle`, { manifest, files });
      const url = this.profileUrl();
      if (!quiet) new import_obsidian4.Notice(`Published: ${url}`);
      return url;
    } catch (e) {
      new import_obsidian4.Notice("Caldera publish failed: " + e.message);
      return null;
    }
  }
  profileUrl() {
    return `${this.settings.hubUrl.replace(/\/$/, "")}/@${this.settings.handle}/`;
  }
  openProfile() {
    if (this.settings.handle) window.open(this.profileUrl());
    else new WelcomeModal(this.app, this).open();
  }
  async exportToFolder() {
    const { text, binaries } = await this.build();
    const root = "Caldera/site";
    for (const [p, t] of Object.entries(text)) await this.write(`${root}/${p}`, t);
    for (const [p, b] of Object.entries(binaries)) await this.writeBinary(`${root}/${p}`, b);
    new import_obsidian4.Notice(`Exported to ${root}. Upload that folder to any static host.`);
  }
  // ---------------------------------------------------------------- inbox
  async syncInbox(loud) {
    try {
      const me = await this.ensureIdentity();
      const [{ envelopes }, fr, gr, cr] = await Promise.all([
        this.api("GET", `/v1/inbox/${encodeURIComponent(me.id)}?since=${encodeURIComponent(this.settings.lastInboxSync)}`, void 0, true),
        this.api("GET", `/v1/friends/${encodeURIComponent(me.id)}`),
        this.api("GET", `/v1/gravity/${encodeURIComponent(me.id)}`),
        this.api("GET", `/v1/credits/${encodeURIComponent(me.id)}`)
      ]);
      this.friends = fr.friends;
      this.social = { friends: fr.friends.length, gravity: gr.gravity, credits: cr.balance };
      let cards = 0;
      for (const e of envelopes) {
        if (!verify(e)) continue;
        if (e.type === "friend.request" && !this.friends.some((f) => f.id === e.from)) this.pending.push({ request: envelopeHash(e), from: e.from, note: e.body.note, ts: e.ts });
        if (e.type === "friend.accept") new import_obsidian4.Notice("Caldera: a friend request was accepted");
        if (e.type === "gravity") new import_obsidian4.Notice(`Caldera: someone gave you gravity${e.body.reason ? ': "' + e.body.reason + '"' : ""}`);
        if (e.type === "card") {
          if (await this.receiveCard(e)) cards++;
        }
        if (e.ts > this.settings.lastInboxSync) this.settings.lastInboxSync = e.ts;
      }
      await this.saveSettings();
      this.refreshPanel();
      if (loud || cards) new import_obsidian4.Notice(`Caldera: inbox synced${cards ? `, ${cards} shared note(s) received` : ""}`);
    } catch (e) {
      if (loud) new import_obsidian4.Notice("Caldera sync failed: " + e.message);
    }
  }
  async receiveCard(e) {
    const me = this.settings.identity;
    const sealed = e.body.payload?.[me.id];
    const sender = this.friends.find((f) => f.id === e.from);
    if (!sealed || !sender?.box_key) return false;
    const text = open(sealed, sender.box_key, me);
    if (text === null) return false;
    const who = sender.handle || e.from.slice(4, 12);
    const safe = String(e.body.title || "Shared note").replace(/[\\/:*?"<>|#^[\]]/g, " ").trim().slice(0, 80);
    const fm = `---
caldera_from: "${who}"
caldera_card: "${e.body.id}"
caldera_version: ${Number(e.body.version) || 1}
caldera_received: ${e.ts}
---
`;
    await this.write(`${this.settings.inboxFolder}/${who}/${safe}.md`, fm + text.replace(/^---[\s\S]*?---\s*/, ""));
    return true;
  }
  async acceptFriend(p) {
    await this.send("friend.accept", { request: p.request, to: p.from });
    this.pending = this.pending.filter((x) => x !== p);
    await this.syncInbox(false);
    new import_obsidian4.Notice("Friend added");
  }
  async requestFriend(handleOrId, note = "") {
    const pr = await this.api("GET", `/v1/profiles/${encodeURIComponent(handleOrId.replace(/^@/, ""))}`);
    await this.send("friend.request", { to: pr.id, note });
    new import_obsidian4.Notice(`Friend request sent to @${pr.handle || pr.id}`);
  }
  async giveGravity(f, reason) {
    const r = await this.send("gravity", { to: f.id, reason: reason.slice(0, 140) });
    new import_obsidian4.Notice(`Gravity sent. @${f.handle || "friend"} now has ${r.gravity}`);
  }
  async shareNote(file) {
    if (!this.friends.length) await this.syncInbox(false);
    if (!this.friends.length) return new import_obsidian4.Notice("Add a friend first (Caldera panel)");
    new FriendPicker(this.app, this.friends, async (f) => {
      if (!f.box_key) return new import_obsidian4.Notice("That friend has not published a profile yet");
      const me = await this.ensureIdentity();
      const text = await this.app.vault.read(file);
      const version = Date.now();
      await this.send("card", {
        id: "card_" + b58encode(new TextEncoder().encode(file.path)).slice(0, 20),
        title: file.basename,
        to: [f.id],
        payload: { [f.id]: seal(text, f.box_key, me) },
        version
      });
      new import_obsidian4.Notice(`Shared "${file.basename}" with @${f.handle || "friend"} (end-to-end encrypted)`);
    }).open();
  }
  // ---------------------------------------------------------------- utils
  async ensureFolder(path) {
    const parts = (0, import_obsidian4.normalizePath)(path).split("/").slice(0, -1);
    let cur = "";
    for (const p of parts) {
      cur = cur ? `${cur}/${p}` : p;
      if (!this.app.vault.getAbstractFileByPath(cur)) await this.app.vault.createFolder(cur).catch(() => {
      });
    }
  }
  async write(path, text) {
    path = (0, import_obsidian4.normalizePath)(path);
    await this.ensureFolder(path);
    const f = this.app.vault.getAbstractFileByPath(path);
    if (f instanceof import_obsidian4.TFile) await this.app.vault.modify(f, text);
    else await this.app.vault.create(path, text);
  }
  async writeBinary(path, data) {
    path = (0, import_obsidian4.normalizePath)(path);
    await this.ensureFolder(path);
    const f = this.app.vault.getAbstractFileByPath(path);
    if (f instanceof import_obsidian4.TFile) await this.app.vault.modifyBinary(f, data);
    else await this.app.vault.createBinary(path, data);
  }
  async openPanel() {
    let leaf = this.app.workspace.getLeavesOfType(VIEW)[0];
    if (!leaf) {
      leaf = this.app.workspace.getRightLeaf(false);
      await leaf.setViewState({ type: VIEW, active: true });
    }
    this.app.workspace.revealLeaf(leaf);
  }
  refreshPanel() {
    for (const l of this.app.workspace.getLeavesOfType(VIEW)) l.view.render();
  }
};
var CalderaView = class extends import_obsidian4.ItemView {
  constructor(leaf, plugin) {
    super(leaf);
    this.plugin = plugin;
  }
  getViewType() {
    return VIEW;
  }
  getDisplayText() {
    return "Caldera";
  }
  getIcon() {
    return "flame";
  }
  async onOpen() {
    this.render();
    this.plugin.syncInbox(false);
  }
  render() {
    const el = this.contentEl;
    el.empty();
    el.addClass("caldera-panel");
    const p = this.plugin, s = p.settings;
    el.createEl("h3", { text: "Caldera" });
    if (!s.identity || !s.handle) {
      el.createEl("p", { text: "Set your name and handle in Settings, then publish your profile to join." });
      new import_obsidian4.Setting(el).addButton((b) => b.setButtonText("Open settings").setCta().onClick(() => {
        this.app.setting.open();
        this.app.setting.openTabById("caldera");
      }));
      return;
    }
    const stats = el.createDiv("caldera-stats");
    for (const [v, l] of [[p.social.friends, "friends"], [p.social.gravity, "gravity"], [p.social.credits, "credits"]])
      stats.createDiv({ cls: "caldera-stat" }).innerHTML = `<b>${v}</b><span>${l}</span>`;
    const actions = el.createDiv("caldera-actions");
    actions.createEl("button", { text: "Preview" }).onclick = () => p.preview();
    actions.createEl("button", { text: "Publish", cls: "mod-cta" }).onclick = () => p.publish();
    actions.createEl("button", { text: "Sync" }).onclick = () => p.syncInbox(true);
    if (p.pending.length) {
      el.createEl("h4", { text: "Friend requests" });
      for (const r of p.pending) {
        const row = el.createDiv("caldera-row");
        row.createSpan({ text: r.from.slice(0, 14) + (r.note ? ` - "${r.note}"` : "") });
        row.createEl("button", { text: "Accept", cls: "mod-cta" }).onclick = () => p.acceptFriend(r);
      }
    }
    el.createEl("h4", { text: "Add a friend" });
    let handle = "";
    new import_obsidian4.Setting(el).addText((t) => t.setPlaceholder("@handle").onChange((v) => handle = v)).addButton((b) => b.setButtonText("Request").onClick(async () => {
      try {
        await p.requestFriend(handle.trim());
      } catch (e) {
        new import_obsidian4.Notice(e.message);
      }
    }));
    el.createEl("h4", { text: `Friends (${p.friends.length})` });
    for (const f of p.friends) {
      const row = el.createDiv("caldera-row");
      row.createSpan({ text: "@" + (f.handle || f.id.slice(4, 12)) + (f.name ? ` - ${f.name}` : "") });
      row.createEl("button", { text: "+ Gravity" }).onclick = () => new GravityModal(this.app, f, (r) => p.giveGravity(f, r)).open();
    }
  }
};
var PreviewModal = class extends import_obsidian4.Modal {
  constructor(app, html) {
    super(app);
    this.html = html;
  }
  onOpen() {
    this.modalEl.addClass("caldera-preview-modal");
    this.titleEl.setText("Public profile preview (exactly what visitors will see)");
    const frame = this.contentEl.createEl("iframe", { cls: "caldera-preview" });
    frame.setAttr("sandbox", "allow-scripts");
    frame.srcdoc = this.html;
  }
};
var FriendPicker = class extends import_obsidian4.SuggestModal {
  constructor(app, list, pick) {
    super(app);
    this.list = list;
    this.pick = pick;
    this.setPlaceholder("Share with which friend?");
  }
  getSuggestions(q2) {
    return this.list.filter((f) => (f.handle || f.name || f.id).toLowerCase().includes(q2.toLowerCase()));
  }
  renderSuggestion(f, el) {
    el.setText("@" + (f.handle || f.id.slice(4, 12)) + (f.name ? ` - ${f.name}` : ""));
  }
  onChooseSuggestion(f) {
    this.pick(f);
  }
};
var GravityModal = class extends import_obsidian4.Modal {
  constructor(app, f, done) {
    super(app);
    this.f = f;
    this.done = done;
  }
  onOpen() {
    this.titleEl.setText(`Add gravity to @${this.f.handle || "friend"}`);
    this.contentEl.createEl("p", { text: "Gravity is positive only. Say what they helped with (optional)." });
    let reason = "";
    new import_obsidian4.Setting(this.contentEl).addText((t) => t.setPlaceholder("They found me an operator").onChange((v) => reason = v)).addButton((b) => b.setButtonText("Add gravity").setCta().onClick(() => {
      this.done(reason);
      this.close();
    }));
  }
};
var ConfirmModal = class extends import_obsidian4.Modal {
  constructor(app, msg, yes) {
    super(app);
    this.msg = msg;
    this.yes = yes;
  }
  onOpen() {
    this.titleEl.setText("Are you sure?");
    this.contentEl.createEl("p", { text: this.msg });
    new import_obsidian4.Setting(this.contentEl).addButton((b) => b.setButtonText("Cancel").onClick(() => this.close())).addButton((b) => b.setButtonText("Delete").setWarning().onClick(() => {
      this.yes();
      this.close();
    }));
  }
};
var AskModal = class extends import_obsidian4.Modal {
  constructor(app, plugin, kind) {
    super(app);
    this.plugin = plugin;
    this.kind = kind;
  }
  onOpen() {
    const ask = this.kind === "ask";
    this.titleEl.setText(ask ? "I could use help with..." : "I can help with...");
    let title = "", bounty = 20;
    new import_obsidian4.Setting(this.contentEl).setName("What").addText((t) => t.onChange((v) => title = v));
    if (ask) new import_obsidian4.Setting(this.contentEl).setName("Bounty (help credits)").setDesc("Held until you award it to whoever helps").addText((t) => t.setValue("20").onChange((v) => bounty = Math.max(0, Number(v) || 0)));
    new import_obsidian4.Setting(this.contentEl).addButton((b) => b.setButtonText(ask ? "Post ask" : "Post offer").setCta().onClick(async () => {
      if (!title.trim()) return;
      try {
        const id = newId(ask ? "ask" : "off");
        await this.plugin.send(ask ? "ask" : "offer", ask ? { id, title, bounty, tags: [], visibility: "public" } : { id, title, tags: [] });
        if (ask) this.plugin.settings.asks.push({ id, title, bounty });
        else this.plugin.settings.offers.push({ id, title });
        await this.plugin.saveSettings();
        new import_obsidian4.Notice(ask ? "Ask posted" : "Offer posted");
        this.close();
      } catch (e) {
        new import_obsidian4.Notice(e.message);
      }
    }));
  }
};
var PromptModal = class extends import_obsidian4.Modal {
  constructor(app, text) {
    super(app);
    this.text = text;
  }
  onOpen() {
    this.titleEl.setText("AI agent setup prompt");
    const ta = this.contentEl.createEl("textarea", { cls: "caldera-prompt" });
    ta.value = this.text;
    ta.rows = 18;
    ta.style.width = "100%";
    ta.readOnly = true;
    ta.select();
  }
  onClose() {
    this.contentEl.empty();
  }
};
var WelcomeModal = class extends import_obsidian4.Modal {
  constructor(app, plugin) {
    super(app);
    this.plugin = plugin;
  }
  onOpen() {
    const s = this.plugin.settings;
    this.modalEl.addClass("caldera-welcome");
    this.titleEl.setText("Welcome to Caldera");
    this.contentEl.createEl("p", { text: "Pick a name and a handle. Caldera creates your identity on this device, publishes your profile, and opens it in your browser. Nothing private leaves your vault." });
    let name = s.name, handle = s.handle, headline = s.headline;
    const status = createEl("div", { cls: "caldera-welcome-status" });
    const clean = (v) => v.toLowerCase().replace(/[^a-z0-9-]/g, "").slice(0, 30);
    new import_obsidian4.Setting(this.contentEl).setName("Your name").addText((t) => t.setPlaceholder("Ada Lovelace").setValue(name).onChange((v) => name = v.trim()));
    new import_obsidian4.Setting(this.contentEl).setName("Handle").setDesc(`${s.hubUrl.replace(/^https?:\/\//, "").replace(/\/$/, "")}/@handle`).addText((t) => t.setPlaceholder("ada").setValue(handle).onChange((v) => {
      handle = clean(v);
      if (v !== handle) t.setValue(handle);
      status.setText("");
    }));
    let listed = s.listed !== false;
    new import_obsidian4.Setting(this.contentEl).setName("List me in the directory").setDesc("Your card appears on the public People page. You can change this anytime.").addToggle((t) => t.setValue(listed).onChange((v) => listed = v));
    new import_obsidian4.Setting(this.contentEl).setName("Headline").setDesc("Optional, one line").addText((t) => t.setPlaceholder("Building things with notes").setValue(headline).onChange((v) => headline = v.trim()));
    this.contentEl.appendChild(status);
    const go = new import_obsidian4.Setting(this.contentEl).addButton((b) => b.setButtonText("Create my profile").setCta().onClick(async () => {
      if (!name) {
        status.setText("Add your name.");
        return;
      }
      if (handle.length < 3) {
        status.setText("Handles need at least 3 letters or numbers.");
        return;
      }
      b.setDisabled(true);
      b.setButtonText("Publishing...");
      try {
        const me = await this.plugin.ensureIdentity(true);
        const r = await (0, import_obsidian4.requestUrl)({ url: `${s.hubUrl.replace(/\/$/, "")}/v1/profiles/${handle}`, throw: false });
        if (r.status === 200 && r.json?.id !== me.id) {
          status.setText(`@${handle} is taken. Try another.`);
          b.setDisabled(false);
          b.setButtonText("Create my profile");
          return;
        }
        Object.assign(s, { name, handle, headline, listed, welcomed: true });
        if (!s.autoPublishHours) s.autoPublishHours = 6;
        await this.plugin.saveSettings();
        this.plugin.scheduleAutoPublish();
        const url = await this.plugin.publish(true);
        if (!url) {
          status.setText("Publishing failed. Check your connection and try again.");
          b.setDisabled(false);
          b.setButtonText("Create my profile");
          return;
        }
        await ensureProfileFile(this.app, s, s.hubUrl).catch(() => {
        });
        window.open(url);
        this.done(url);
      } catch (e) {
        status.setText(e.message);
        b.setDisabled(false);
        b.setButtonText("Create my profile");
      }
    }));
    go.settingEl.addClass("caldera-welcome-go");
  }
  done(url) {
    this.contentEl.empty();
    this.titleEl.setText("Your profile is live");
    const link = this.contentEl.createEl("p").createEl("a", { text: url, href: url });
    link.addEventListener("click", (e) => {
      e.preventDefault();
      window.open(url);
    });
    this.contentEl.createEl("p", { text: "It updates itself from your vault. To change your name, headline, photo, links or sections, edit the note Caldera/profile.md - or ask your AI agent to. The page republishes about a minute after you save." });
    this.contentEl.createEl("p", { text: "Your login is a key stored in this vault - no password. Save a copy so you can recover your profile on another device:", cls: "caldera-welcome-key" });
    new import_obsidian4.Setting(this.contentEl).addButton((b) => b.setButtonText("Copy recovery key").onClick(async () => {
      await navigator.clipboard.writeText(btoa(JSON.stringify(this.plugin.settings.identity)));
      new import_obsidian4.Notice("Recovery key copied. Paste it into your password manager. Anyone with it can act as you.");
    })).addButton((b) => b.setButtonText("Open my profile").setCta().onClick(() => window.open(url))).addButton((b) => b.setButtonText("Done").onClick(() => this.close()));
  }
  onClose() {
    this.contentEl.empty();
  }
};
var WhatsNewModal = class extends import_obsidian4.Modal {
  constructor(app, plugin, releases) {
    super(app);
    this.plugin = plugin;
    this.releases = releases;
  }
  onOpen() {
    this.titleEl.setText("What's new in Caldera");
    for (const r of this.releases) {
      const box = this.contentEl.createDiv({ cls: "caldera-release" });
      box.createEl("div", { cls: "caldera-release-meta", text: `${r.version} \xB7 ${r.date}` });
      box.createEl("h3", { text: r.title });
      const ul = box.createEl("ul");
      for (const it of r.items) ul.createEl("li", { text: it });
      if (r.howto) box.createEl("p", { cls: "caldera-release-howto", text: r.howto });
    }
    const hub = this.plugin.settings.hubUrl.replace(/\/$/, "");
    new import_obsidian4.Setting(this.contentEl).addButton((b) => b.setButtonText("All release notes").onClick(() => window.open(hub + "/changelog.html"))).addButton((b) => b.setButtonText("Guide").onClick(() => window.open(hub + "/guide.html"))).addButton((b) => b.setButtonText("Done").setCta().onClick(() => this.close()));
  }
  onClose() {
    this.contentEl.empty();
  }
};
